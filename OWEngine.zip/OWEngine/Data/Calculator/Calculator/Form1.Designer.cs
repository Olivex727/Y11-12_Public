﻿namespace Calculator
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            this.button1 = new System.Windows.Forms.Button();
            this.button2 = new System.Windows.Forms.Button();
            this.button3 = new System.Windows.Forms.Button();
            this.button4 = new System.Windows.Forms.Button();
            this.button5 = new System.Windows.Forms.Button();
            this.button6 = new System.Windows.Forms.Button();
            this.button7 = new System.Windows.Forms.Button();
            this.button8 = new System.Windows.Forms.Button();
            this.button9 = new System.Windows.Forms.Button();
            this.button0 = new System.Windows.Forms.Button();
            this.buttondot = new System.Windows.Forms.Button();
            this.buttonClear = new System.Windows.Forms.Button();
            this.buttonPlus = new System.Windows.Forms.Button();
            this.buttonDiv = new System.Windows.Forms.Button();
            this.buttonMult = new System.Windows.Forms.Button();
            this.buttonMinus = new System.Windows.Forms.Button();
            this.InputBox = new System.Windows.Forms.TextBox();
            this.label1 = new System.Windows.Forms.Label();
            this.timer1 = new System.Windows.Forms.Timer(this.components);
            this.menuStrip1 = new System.Windows.Forms.MenuStrip();
            this.viewToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.historyToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.calculationsToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.baseConversionToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.notesToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.clearToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.historyToolStripMenuItem1 = new System.Windows.Forms.ToolStripMenuItem();
            this.notesToolStripMenuItem1 = new System.Windows.Forms.ToolStripMenuItem();
            this.calculationsToolStripMenuItem1 = new System.Windows.Forms.ToolStripMenuItem();
            this.allToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.buttonPower = new System.Windows.Forms.Button();
            this.buttonLog = new System.Windows.Forms.Button();
            this.buttonFact = new System.Windows.Forms.Button();
            this.buttonRoot = new System.Windows.Forms.Button();
            this.buttonSin = new System.Windows.Forms.Button();
            this.buttonCos = new System.Windows.Forms.Button();
            this.buttonTan = new System.Windows.Forms.Button();
            this.buttonAbs = new System.Windows.Forms.Button();
            this.InterfaceChange = new System.Windows.Forms.Timer(this.components);
            this.textBox1 = new System.Windows.Forms.TextBox();
            this.Hexlabel = new System.Windows.Forms.Label();
            this.DecimalLabel = new System.Windows.Forms.Label();
            this.BinaryText = new System.Windows.Forms.TextBox();
            this.HexText = new System.Windows.Forms.TextBox();
            this.DecText = new System.Windows.Forms.TextBox();
            this.OctText = new System.Windows.Forms.TextBox();
            this.label2 = new System.Windows.Forms.Label();
            this.ExpandButton = new System.Windows.Forms.Button();
            this.buttonAC = new System.Windows.Forms.Button();
            this.buttonC = new System.Windows.Forms.Button();
            this.BinaryLabel = new System.Windows.Forms.Label();
            this.historyList = new System.Windows.Forms.ListBox();
            this.Totals = new System.Windows.Forms.ListBox();
            this.menuStrip1.SuspendLayout();
            this.SuspendLayout();
            // 
            // button1
            // 
            this.button1.Location = new System.Drawing.Point(14, 244);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(80, 50);
            this.button1.TabIndex = 1;
            this.button1.Tag = "simp";
            this.button1.Text = "1";
            this.button1.UseVisualStyleBackColor = true;
            this.button1.Click += new System.EventHandler(this.button1_Click);
            // 
            // button2
            // 
            this.button2.Location = new System.Drawing.Point(100, 244);
            this.button2.Name = "button2";
            this.button2.Size = new System.Drawing.Size(80, 50);
            this.button2.TabIndex = 2;
            this.button2.Tag = "simp";
            this.button2.Text = "2";
            this.button2.UseVisualStyleBackColor = true;
            this.button2.Click += new System.EventHandler(this.button2_Click);
            // 
            // button3
            // 
            this.button3.Location = new System.Drawing.Point(186, 244);
            this.button3.Name = "button3";
            this.button3.Size = new System.Drawing.Size(80, 50);
            this.button3.TabIndex = 3;
            this.button3.Tag = "simp";
            this.button3.Text = "3";
            this.button3.UseVisualStyleBackColor = true;
            this.button3.Click += new System.EventHandler(this.button3_Click);
            // 
            // button4
            // 
            this.button4.Location = new System.Drawing.Point(14, 188);
            this.button4.Name = "button4";
            this.button4.Size = new System.Drawing.Size(80, 50);
            this.button4.TabIndex = 4;
            this.button4.Tag = "simp";
            this.button4.Text = "4";
            this.button4.UseVisualStyleBackColor = true;
            this.button4.Click += new System.EventHandler(this.button4_Click);
            // 
            // button5
            // 
            this.button5.Location = new System.Drawing.Point(100, 188);
            this.button5.Name = "button5";
            this.button5.Size = new System.Drawing.Size(80, 50);
            this.button5.TabIndex = 5;
            this.button5.Tag = "simp";
            this.button5.Text = "5";
            this.button5.UseVisualStyleBackColor = true;
            this.button5.Click += new System.EventHandler(this.button5_Click);
            // 
            // button6
            // 
            this.button6.Location = new System.Drawing.Point(186, 188);
            this.button6.Name = "button6";
            this.button6.Size = new System.Drawing.Size(80, 50);
            this.button6.TabIndex = 6;
            this.button6.Tag = "simp";
            this.button6.Text = "6";
            this.button6.UseVisualStyleBackColor = true;
            this.button6.Click += new System.EventHandler(this.button6_Click);
            // 
            // button7
            // 
            this.button7.Location = new System.Drawing.Point(14, 132);
            this.button7.Name = "button7";
            this.button7.Size = new System.Drawing.Size(80, 50);
            this.button7.TabIndex = 7;
            this.button7.Tag = "simp";
            this.button7.Text = "7";
            this.button7.UseVisualStyleBackColor = true;
            this.button7.Click += new System.EventHandler(this.button7_Click);
            // 
            // button8
            // 
            this.button8.Location = new System.Drawing.Point(100, 132);
            this.button8.Name = "button8";
            this.button8.Size = new System.Drawing.Size(80, 50);
            this.button8.TabIndex = 8;
            this.button8.Tag = "simp";
            this.button8.Text = "8";
            this.button8.UseVisualStyleBackColor = true;
            this.button8.Click += new System.EventHandler(this.button8_Click);
            // 
            // button9
            // 
            this.button9.Location = new System.Drawing.Point(186, 132);
            this.button9.Name = "button9";
            this.button9.Size = new System.Drawing.Size(80, 50);
            this.button9.TabIndex = 9;
            this.button9.Tag = "simp";
            this.button9.Text = "9";
            this.button9.UseVisualStyleBackColor = true;
            this.button9.Click += new System.EventHandler(this.button9_Click);
            // 
            // button0
            // 
            this.button0.Location = new System.Drawing.Point(100, 300);
            this.button0.Name = "button0";
            this.button0.Size = new System.Drawing.Size(80, 50);
            this.button0.TabIndex = 10;
            this.button0.Tag = "simp";
            this.button0.Text = "0";
            this.button0.UseVisualStyleBackColor = true;
            this.button0.Click += new System.EventHandler(this.button0_Click);
            // 
            // buttondot
            // 
            this.buttondot.Location = new System.Drawing.Point(14, 300);
            this.buttondot.Name = "buttondot";
            this.buttondot.Size = new System.Drawing.Size(80, 50);
            this.buttondot.TabIndex = 11;
            this.buttondot.Tag = "simp";
            this.buttondot.Text = ".";
            this.buttondot.UseVisualStyleBackColor = true;
            this.buttondot.Click += new System.EventHandler(this.buttondot_Click);
            // 
            // buttonClear
            // 
            this.buttonClear.Location = new System.Drawing.Point(186, 300);
            this.buttonClear.Name = "buttonClear";
            this.buttonClear.Size = new System.Drawing.Size(80, 50);
            this.buttonClear.TabIndex = 12;
            this.buttonClear.Tag = "simp";
            this.buttonClear.Text = "=";
            this.buttonClear.UseVisualStyleBackColor = true;
            this.buttonClear.Click += new System.EventHandler(this.buttonClear_Click);
            // 
            // buttonPlus
            // 
            this.buttonPlus.Location = new System.Drawing.Point(272, 132);
            this.buttonPlus.Name = "buttonPlus";
            this.buttonPlus.Size = new System.Drawing.Size(80, 50);
            this.buttonPlus.TabIndex = 13;
            this.buttonPlus.Tag = "simp";
            this.buttonPlus.Text = "+";
            this.buttonPlus.UseVisualStyleBackColor = true;
            this.buttonPlus.Click += new System.EventHandler(this.buttonEqual_Click);
            // 
            // buttonDiv
            // 
            this.buttonDiv.Location = new System.Drawing.Point(272, 300);
            this.buttonDiv.Name = "buttonDiv";
            this.buttonDiv.Size = new System.Drawing.Size(80, 50);
            this.buttonDiv.TabIndex = 14;
            this.buttonDiv.Tag = "simp";
            this.buttonDiv.Text = "/";
            this.buttonDiv.UseVisualStyleBackColor = true;
            this.buttonDiv.Click += new System.EventHandler(this.buttonDiv_Click);
            // 
            // buttonMult
            // 
            this.buttonMult.Location = new System.Drawing.Point(272, 244);
            this.buttonMult.Name = "buttonMult";
            this.buttonMult.Size = new System.Drawing.Size(80, 50);
            this.buttonMult.TabIndex = 15;
            this.buttonMult.Tag = "simp";
            this.buttonMult.Text = "*";
            this.buttonMult.UseVisualStyleBackColor = true;
            this.buttonMult.Click += new System.EventHandler(this.buttonMult_Click);
            // 
            // buttonMinus
            // 
            this.buttonMinus.Location = new System.Drawing.Point(272, 188);
            this.buttonMinus.Name = "buttonMinus";
            this.buttonMinus.Size = new System.Drawing.Size(80, 50);
            this.buttonMinus.TabIndex = 16;
            this.buttonMinus.Tag = "simp";
            this.buttonMinus.Text = "-";
            this.buttonMinus.UseVisualStyleBackColor = true;
            this.buttonMinus.Click += new System.EventHandler(this.buttonMinus_Click);
            // 
            // InputBox
            // 
            this.InputBox.Font = new System.Drawing.Font("Microsoft Sans Serif", 30F);
            this.InputBox.Location = new System.Drawing.Point(14, 62);
            this.InputBox.Multiline = true;
            this.InputBox.Name = "InputBox";
            this.InputBox.ReadOnly = true;
            this.InputBox.Size = new System.Drawing.Size(424, 64);
            this.InputBox.TabIndex = 17;
            this.InputBox.Tag = "simp";
            this.InputBox.WordWrap = false;
            // 
            // label1
            // 
            this.label1.Location = new System.Drawing.Point(15, 38);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(422, 21);
            this.label1.TabIndex = 18;
            this.label1.Tag = "simp";
            this.label1.Text = "=";
            this.label1.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // timer1
            // 
            this.timer1.Enabled = true;
            this.timer1.Interval = 10;
            this.timer1.Tick += new System.EventHandler(this.timer1_Tick);
            // 
            // menuStrip1
            // 
            this.menuStrip1.ImageScalingSize = new System.Drawing.Size(20, 20);
            this.menuStrip1.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.viewToolStripMenuItem,
            this.clearToolStripMenuItem});
            this.menuStrip1.Location = new System.Drawing.Point(0, 0);
            this.menuStrip1.Name = "menuStrip1";
            this.menuStrip1.Size = new System.Drawing.Size(662, 28);
            this.menuStrip1.TabIndex = 21;
            this.menuStrip1.Tag = "simp";
            this.menuStrip1.Text = "menuStrip1";
            // 
            // viewToolStripMenuItem
            // 
            this.viewToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.historyToolStripMenuItem,
            this.calculationsToolStripMenuItem,
            this.baseConversionToolStripMenuItem,
            this.notesToolStripMenuItem});
            this.viewToolStripMenuItem.Name = "viewToolStripMenuItem";
            this.viewToolStripMenuItem.Size = new System.Drawing.Size(53, 24);
            this.viewToolStripMenuItem.Tag = "simp";
            this.viewToolStripMenuItem.Text = "View";
            this.viewToolStripMenuItem.Click += new System.EventHandler(this.viewToolStripMenuItem_Click);
            // 
            // historyToolStripMenuItem
            // 
            this.historyToolStripMenuItem.Name = "historyToolStripMenuItem";
            this.historyToolStripMenuItem.Size = new System.Drawing.Size(192, 26);
            this.historyToolStripMenuItem.Tag = "simp";
            this.historyToolStripMenuItem.Text = "History";
            this.historyToolStripMenuItem.Click += new System.EventHandler(this.historyToolStripMenuItem_Click);
            // 
            // calculationsToolStripMenuItem
            // 
            this.calculationsToolStripMenuItem.Name = "calculationsToolStripMenuItem";
            this.calculationsToolStripMenuItem.Size = new System.Drawing.Size(192, 26);
            this.calculationsToolStripMenuItem.Tag = "simp";
            this.calculationsToolStripMenuItem.Text = "Calculations";
            this.calculationsToolStripMenuItem.Click += new System.EventHandler(this.calculationsToolStripMenuItem_Click);
            // 
            // baseConversionToolStripMenuItem
            // 
            this.baseConversionToolStripMenuItem.Name = "baseConversionToolStripMenuItem";
            this.baseConversionToolStripMenuItem.Size = new System.Drawing.Size(192, 26);
            this.baseConversionToolStripMenuItem.Tag = "simp";
            this.baseConversionToolStripMenuItem.Text = "Base Conversion";
            this.baseConversionToolStripMenuItem.Click += new System.EventHandler(this.baseConversionToolStripMenuItem_Click);
            // 
            // notesToolStripMenuItem
            // 
            this.notesToolStripMenuItem.Name = "notesToolStripMenuItem";
            this.notesToolStripMenuItem.Size = new System.Drawing.Size(192, 26);
            this.notesToolStripMenuItem.Tag = "simp";
            this.notesToolStripMenuItem.Text = "Notes";
            this.notesToolStripMenuItem.Click += new System.EventHandler(this.notesToolStripMenuItem_Click);
            // 
            // clearToolStripMenuItem
            // 
            this.clearToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.historyToolStripMenuItem1,
            this.notesToolStripMenuItem1,
            this.calculationsToolStripMenuItem1,
            this.allToolStripMenuItem});
            this.clearToolStripMenuItem.Name = "clearToolStripMenuItem";
            this.clearToolStripMenuItem.Size = new System.Drawing.Size(55, 24);
            this.clearToolStripMenuItem.Tag = "simp";
            this.clearToolStripMenuItem.Text = "Clear";
            // 
            // historyToolStripMenuItem1
            // 
            this.historyToolStripMenuItem1.Name = "historyToolStripMenuItem1";
            this.historyToolStripMenuItem1.Size = new System.Drawing.Size(164, 26);
            this.historyToolStripMenuItem1.Tag = "simp";
            this.historyToolStripMenuItem1.Text = "History";
            this.historyToolStripMenuItem1.Click += new System.EventHandler(this.historyToolStripMenuItem1_Click);
            // 
            // notesToolStripMenuItem1
            // 
            this.notesToolStripMenuItem1.Name = "notesToolStripMenuItem1";
            this.notesToolStripMenuItem1.Size = new System.Drawing.Size(164, 26);
            this.notesToolStripMenuItem1.Tag = "simp";
            this.notesToolStripMenuItem1.Text = "Notes";
            this.notesToolStripMenuItem1.Click += new System.EventHandler(this.notesToolStripMenuItem1_Click);
            // 
            // calculationsToolStripMenuItem1
            // 
            this.calculationsToolStripMenuItem1.Name = "calculationsToolStripMenuItem1";
            this.calculationsToolStripMenuItem1.Size = new System.Drawing.Size(164, 26);
            this.calculationsToolStripMenuItem1.Tag = "simp";
            this.calculationsToolStripMenuItem1.Text = "Calculations";
            this.calculationsToolStripMenuItem1.Click += new System.EventHandler(this.calculationsToolStripMenuItem1_Click);
            // 
            // allToolStripMenuItem
            // 
            this.allToolStripMenuItem.Name = "allToolStripMenuItem";
            this.allToolStripMenuItem.Size = new System.Drawing.Size(164, 26);
            this.allToolStripMenuItem.Text = "All";
            this.allToolStripMenuItem.Click += new System.EventHandler(this.allToolStripMenuItem_Click);
            // 
            // buttonPower
            // 
            this.buttonPower.Location = new System.Drawing.Point(487, 132);
            this.buttonPower.Name = "buttonPower";
            this.buttonPower.Size = new System.Drawing.Size(80, 50);
            this.buttonPower.TabIndex = 22;
            this.buttonPower.Tag = "calc";
            this.buttonPower.Text = "^";
            this.buttonPower.UseVisualStyleBackColor = true;
            this.buttonPower.Click += new System.EventHandler(this.buttonPower_Click);
            // 
            // buttonLog
            // 
            this.buttonLog.Location = new System.Drawing.Point(487, 188);
            this.buttonLog.Name = "buttonLog";
            this.buttonLog.Size = new System.Drawing.Size(80, 50);
            this.buttonLog.TabIndex = 23;
            this.buttonLog.Tag = "calc";
            this.buttonLog.Text = "ln";
            this.buttonLog.UseVisualStyleBackColor = true;
            this.buttonLog.Click += new System.EventHandler(this.buttonLog_Click);
            // 
            // buttonFact
            // 
            this.buttonFact.Location = new System.Drawing.Point(487, 244);
            this.buttonFact.Name = "buttonFact";
            this.buttonFact.Size = new System.Drawing.Size(80, 50);
            this.buttonFact.TabIndex = 24;
            this.buttonFact.Tag = "calc";
            this.buttonFact.Text = "!";
            this.buttonFact.UseVisualStyleBackColor = true;
            this.buttonFact.Click += new System.EventHandler(this.buttonFact_Click);
            // 
            // buttonRoot
            // 
            this.buttonRoot.Location = new System.Drawing.Point(487, 300);
            this.buttonRoot.Name = "buttonRoot";
            this.buttonRoot.Size = new System.Drawing.Size(80, 50);
            this.buttonRoot.TabIndex = 25;
            this.buttonRoot.Tag = "calc";
            this.buttonRoot.Text = "Root";
            this.buttonRoot.UseVisualStyleBackColor = true;
            this.buttonRoot.Click += new System.EventHandler(this.buttonRoot_Click);
            // 
            // buttonSin
            // 
            this.buttonSin.Location = new System.Drawing.Point(573, 132);
            this.buttonSin.Name = "buttonSin";
            this.buttonSin.Size = new System.Drawing.Size(80, 50);
            this.buttonSin.TabIndex = 26;
            this.buttonSin.Tag = "calc";
            this.buttonSin.Text = "Sin";
            this.buttonSin.UseVisualStyleBackColor = true;
            this.buttonSin.Click += new System.EventHandler(this.buttonSin_Click);
            // 
            // buttonCos
            // 
            this.buttonCos.Location = new System.Drawing.Point(573, 188);
            this.buttonCos.Name = "buttonCos";
            this.buttonCos.Size = new System.Drawing.Size(80, 50);
            this.buttonCos.TabIndex = 27;
            this.buttonCos.Tag = "calc";
            this.buttonCos.Text = "Cos";
            this.buttonCos.UseVisualStyleBackColor = true;
            this.buttonCos.Click += new System.EventHandler(this.buttonCos_Click);
            // 
            // buttonTan
            // 
            this.buttonTan.Location = new System.Drawing.Point(573, 244);
            this.buttonTan.Name = "buttonTan";
            this.buttonTan.Size = new System.Drawing.Size(80, 50);
            this.buttonTan.TabIndex = 28;
            this.buttonTan.Tag = "calc";
            this.buttonTan.Text = "Tan";
            this.buttonTan.UseVisualStyleBackColor = true;
            this.buttonTan.Click += new System.EventHandler(this.buttonTan_Click);
            // 
            // buttonAbs
            // 
            this.buttonAbs.Location = new System.Drawing.Point(573, 300);
            this.buttonAbs.Name = "buttonAbs";
            this.buttonAbs.Size = new System.Drawing.Size(80, 50);
            this.buttonAbs.TabIndex = 29;
            this.buttonAbs.Tag = "calc";
            this.buttonAbs.Text = "Abs";
            this.buttonAbs.UseVisualStyleBackColor = true;
            this.buttonAbs.Click += new System.EventHandler(this.buttonAbs_Click);
            // 
            // InterfaceChange
            // 
            this.InterfaceChange.Enabled = true;
            this.InterfaceChange.Interval = 50;
            this.InterfaceChange.Tick += new System.EventHandler(this.InterfaceChange_Tick);
            // 
            // textBox1
            // 
            this.textBox1.Location = new System.Drawing.Point(443, 44);
            this.textBox1.Multiline = true;
            this.textBox1.Name = "textBox1";
            this.textBox1.Size = new System.Drawing.Size(210, 306);
            this.textBox1.TabIndex = 30;
            this.textBox1.Tag = "notes";
            // 
            // Hexlabel
            // 
            this.Hexlabel.AutoSize = true;
            this.Hexlabel.Font = new System.Drawing.Font("Microsoft Sans Serif", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Hexlabel.Location = new System.Drawing.Point(451, 132);
            this.Hexlabel.Name = "Hexlabel";
            this.Hexlabel.Size = new System.Drawing.Size(152, 29);
            this.Hexlabel.TabIndex = 32;
            this.Hexlabel.Tag = "base";
            this.Hexlabel.Text = "Hexidecimal:";
            this.Hexlabel.Click += new System.EventHandler(this.Hexlabel_Click);
            // 
            // DecimalLabel
            // 
            this.DecimalLabel.AutoSize = true;
            this.DecimalLabel.Font = new System.Drawing.Font("Microsoft Sans Serif", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.DecimalLabel.Location = new System.Drawing.Point(451, 279);
            this.DecimalLabel.Name = "DecimalLabel";
            this.DecimalLabel.Size = new System.Drawing.Size(107, 29);
            this.DecimalLabel.TabIndex = 33;
            this.DecimalLabel.Tag = "base";
            this.DecimalLabel.Text = "Decimal:";
            this.DecimalLabel.Click += new System.EventHandler(this.DecimalLabel_Click);
            // 
            // BinaryText
            // 
            this.BinaryText.Font = new System.Drawing.Font("Microsoft Sans Serif", 15F);
            this.BinaryText.Location = new System.Drawing.Point(456, 91);
            this.BinaryText.Multiline = true;
            this.BinaryText.Name = "BinaryText";
            this.BinaryText.Size = new System.Drawing.Size(194, 35);
            this.BinaryText.TabIndex = 35;
            this.BinaryText.Tag = "base";
            this.BinaryText.TextChanged += new System.EventHandler(this.BinaryText_TextChanged);
            // 
            // HexText
            // 
            this.HexText.Font = new System.Drawing.Font("Microsoft Sans Serif", 15F);
            this.HexText.Location = new System.Drawing.Point(456, 164);
            this.HexText.Multiline = true;
            this.HexText.Name = "HexText";
            this.HexText.Size = new System.Drawing.Size(194, 35);
            this.HexText.TabIndex = 36;
            this.HexText.Tag = "base";
            this.HexText.TextChanged += new System.EventHandler(this.HexText_TextChanged);
            // 
            // DecText
            // 
            this.DecText.Font = new System.Drawing.Font("Microsoft Sans Serif", 15F);
            this.DecText.Location = new System.Drawing.Point(456, 311);
            this.DecText.Multiline = true;
            this.DecText.Name = "DecText";
            this.DecText.Size = new System.Drawing.Size(194, 35);
            this.DecText.TabIndex = 37;
            this.DecText.Tag = "base";
            this.DecText.TextChanged += new System.EventHandler(this.DecText_TextChanged);
            // 
            // OctText
            // 
            this.OctText.Font = new System.Drawing.Font("Microsoft Sans Serif", 15F);
            this.OctText.Location = new System.Drawing.Point(456, 238);
            this.OctText.Multiline = true;
            this.OctText.Name = "OctText";
            this.OctText.Size = new System.Drawing.Size(194, 35);
            this.OctText.TabIndex = 38;
            this.OctText.Tag = "base";
            this.OctText.TextChanged += new System.EventHandler(this.OctText_TextChanged);
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Microsoft Sans Serif", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.Location = new System.Drawing.Point(451, 206);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(107, 29);
            this.label2.TabIndex = 39;
            this.label2.Tag = "base";
            this.label2.Text = "Octinary:";
            // 
            // ExpandButton
            // 
            this.ExpandButton.Location = new System.Drawing.Point(358, 132);
            this.ExpandButton.Name = "ExpandButton";
            this.ExpandButton.Size = new System.Drawing.Size(80, 106);
            this.ExpandButton.TabIndex = 0;
            this.ExpandButton.Tag = "simp";
            this.ExpandButton.Text = "Expand Window";
            this.ExpandButton.UseVisualStyleBackColor = true;
            this.ExpandButton.Click += new System.EventHandler(this.ExpandButton_Click);
            // 
            // buttonAC
            // 
            this.buttonAC.Location = new System.Drawing.Point(357, 300);
            this.buttonAC.Name = "buttonAC";
            this.buttonAC.Size = new System.Drawing.Size(80, 50);
            this.buttonAC.TabIndex = 19;
            this.buttonAC.Tag = "simp";
            this.buttonAC.Text = "CE";
            this.buttonAC.UseVisualStyleBackColor = true;
            this.buttonAC.Click += new System.EventHandler(this.buttonAC_Click);
            // 
            // buttonC
            // 
            this.buttonC.Location = new System.Drawing.Point(357, 244);
            this.buttonC.Name = "buttonC";
            this.buttonC.Size = new System.Drawing.Size(80, 50);
            this.buttonC.TabIndex = 20;
            this.buttonC.Tag = "simp";
            this.buttonC.Text = "C";
            this.buttonC.UseVisualStyleBackColor = true;
            this.buttonC.Click += new System.EventHandler(this.buttonC_Click);
            // 
            // BinaryLabel
            // 
            this.BinaryLabel.AutoSize = true;
            this.BinaryLabel.Font = new System.Drawing.Font("Microsoft Sans Serif", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.BinaryLabel.Location = new System.Drawing.Point(451, 52);
            this.BinaryLabel.Name = "BinaryLabel";
            this.BinaryLabel.Size = new System.Drawing.Size(86, 29);
            this.BinaryLabel.TabIndex = 31;
            this.BinaryLabel.Tag = "base";
            this.BinaryLabel.Text = "Binary:";
            this.BinaryLabel.Click += new System.EventHandler(this.BinaryLabel_Click);
            // 
            // historyList
            // 
            this.historyList.FormattingEnabled = true;
            this.historyList.HorizontalScrollbar = true;
            this.historyList.ItemHeight = 16;
            this.historyList.Location = new System.Drawing.Point(340, 44);
            this.historyList.Name = "historyList";
            this.historyList.Size = new System.Drawing.Size(105, 308);
            this.historyList.TabIndex = 40;
            this.historyList.Tag = "history";
            this.historyList.SelectedIndexChanged += new System.EventHandler(this.historyList_SelectedIndexChanged);
            // 
            // Totals
            // 
            this.Totals.FormattingEnabled = true;
            this.Totals.ItemHeight = 16;
            this.Totals.Location = new System.Drawing.Point(548, 44);
            this.Totals.Name = "Totals";
            this.Totals.Size = new System.Drawing.Size(105, 308);
            this.Totals.TabIndex = 41;
            this.Totals.Tag = "history";
            this.Totals.SelectedIndexChanged += new System.EventHandler(this.Totals_SelectedIndexChanged);
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(662, 358);
            this.Controls.Add(this.buttonAbs);
            this.Controls.Add(this.buttonTan);
            this.Controls.Add(this.buttonCos);
            this.Controls.Add(this.buttonSin);
            this.Controls.Add(this.buttonRoot);
            this.Controls.Add(this.buttonFact);
            this.Controls.Add(this.buttonLog);
            this.Controls.Add(this.buttonPower);
            this.Controls.Add(this.buttonC);
            this.Controls.Add(this.buttonAC);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.InputBox);
            this.Controls.Add(this.buttonMinus);
            this.Controls.Add(this.buttonMult);
            this.Controls.Add(this.buttonDiv);
            this.Controls.Add(this.buttonPlus);
            this.Controls.Add(this.buttonClear);
            this.Controls.Add(this.buttondot);
            this.Controls.Add(this.button0);
            this.Controls.Add(this.button9);
            this.Controls.Add(this.button8);
            this.Controls.Add(this.button7);
            this.Controls.Add(this.button6);
            this.Controls.Add(this.button5);
            this.Controls.Add(this.button4);
            this.Controls.Add(this.button3);
            this.Controls.Add(this.button2);
            this.Controls.Add(this.button1);
            this.Controls.Add(this.ExpandButton);
            this.Controls.Add(this.menuStrip1);
            this.Controls.Add(this.Totals);
            this.Controls.Add(this.historyList);
            this.Controls.Add(this.BinaryText);
            this.Controls.Add(this.BinaryLabel);
            this.Controls.Add(this.Hexlabel);
            this.Controls.Add(this.HexText);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.OctText);
            this.Controls.Add(this.DecimalLabel);
            this.Controls.Add(this.DecText);
            this.Controls.Add(this.textBox1);
            this.MainMenuStrip = this.menuStrip1;
            this.MaximizeBox = false;
            this.MaximumSize = new System.Drawing.Size(680, 405);
            this.MinimumSize = new System.Drawing.Size(460, 405);
            this.Name = "Form1";
            this.Tag = "simp";
            this.Text = "OW Calculator";
            this.menuStrip1.ResumeLayout(false);
            this.menuStrip1.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion
        private System.Windows.Forms.Button button1;
        private System.Windows.Forms.Button button2;
        private System.Windows.Forms.Button button3;
        private System.Windows.Forms.Button button4;
        private System.Windows.Forms.Button button5;
        private System.Windows.Forms.Button button6;
        private System.Windows.Forms.Button button7;
        private System.Windows.Forms.Button button8;
        private System.Windows.Forms.Button button9;
        private System.Windows.Forms.Button button0;
        private System.Windows.Forms.Button buttondot;
        private System.Windows.Forms.Button buttonClear;
        private System.Windows.Forms.Button buttonPlus;
        private System.Windows.Forms.Button buttonDiv;
        private System.Windows.Forms.Button buttonMult;
        private System.Windows.Forms.Button buttonMinus;
        private System.Windows.Forms.TextBox InputBox;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Timer timer1;
        private System.Windows.Forms.MenuStrip menuStrip1;
        private System.Windows.Forms.ToolStripMenuItem viewToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem historyToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem calculationsToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem baseConversionToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem notesToolStripMenuItem;
        private System.Windows.Forms.Button buttonPower;
        private System.Windows.Forms.Button buttonLog;
        private System.Windows.Forms.Button buttonFact;
        private System.Windows.Forms.Button buttonRoot;
        private System.Windows.Forms.Button buttonSin;
        private System.Windows.Forms.Button buttonCos;
        private System.Windows.Forms.Button buttonTan;
        private System.Windows.Forms.Button buttonAbs;
        private System.Windows.Forms.Timer InterfaceChange;
        private System.Windows.Forms.TextBox textBox1;
        private System.Windows.Forms.Label Hexlabel;
        private System.Windows.Forms.Label DecimalLabel;
        private System.Windows.Forms.TextBox BinaryText;
        private System.Windows.Forms.TextBox HexText;
        private System.Windows.Forms.TextBox DecText;
        private System.Windows.Forms.TextBox OctText;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Button ExpandButton;
        private System.Windows.Forms.Button buttonAC;
        private System.Windows.Forms.Button buttonC;
        private System.Windows.Forms.Label BinaryLabel;
        private System.Windows.Forms.ListBox historyList;
        private System.Windows.Forms.ListBox Totals;
        private System.Windows.Forms.ToolStripMenuItem clearToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem historyToolStripMenuItem1;
        private System.Windows.Forms.ToolStripMenuItem notesToolStripMenuItem1;
        private System.Windows.Forms.ToolStripMenuItem calculationsToolStripMenuItem1;
        private System.Windows.Forms.ToolStripMenuItem allToolStripMenuItem;
    }
}

