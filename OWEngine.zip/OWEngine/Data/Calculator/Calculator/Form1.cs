﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Calculator
{
    public partial class Form1 : Form
    {


        public bool SizeCheck = true;
        public bool operantCheck = false;
        public double z = 0;
        public double a = 0;
        public string o = "";
        public string inter = "calc";
        public string previnter = "calc";
        public double total = 0;
        public string calculation = "";
        public string BaseTag = "dec";
        public string prev = "nvrejverhbvie";

        public Form1()
        {
            
            InitializeComponent();
            //CreateButtonArray();
        }

        //private void CreateButtonArray()
        //{
        //    for(int y = 0; y < 4; y++)
        //    {
        //        for (int x = 0; x < 4; x++)
        //        {
                    
        //            Button Number = new Button();
        //            if(x == 3)
        //            {
        //                Number.Text = chararray[y+3].ToString();
        //            }
        //            else if(y == 0)
        //            {
        //                Number.Text = chararray[x].ToString();
        //            }
        //            else
        //            {
        //                ArrCount++;
        //                Number.Text = ArrCount.ToString();
        //                //Number.Font.Bold = true;
        //            }
        //            Number.Left = 20 + (x) * 80;
        //            Number.Top = 250 - (y) * 50;
        //            Number.Size = new Size(80, 50);

        //            Numpad[x, y] = Number;
        //            Controls.Add(Number);
        //        }
        //    }
        //}

        private void Calculate(string input){
            //if(input != "=" && prev == "=")
            //{
            //    InputBox.Text = "";
            //}
            if(o == "")
            {
                if (!double.TryParse(InputBox.Text, out a)){a=0; }
                total = a;
                o = input;
                InputBox.Text = "";
                calculation += a.ToString();
            }
            else
            {
                try
                {
                    calculation += " " + o + " " + InputBox.Text;
                    if (o == "+") { total = a + Convert.ToDouble(InputBox.Text); }
                    else if (o == "-") { total = a - Convert.ToDouble(InputBox.Text); }
                    else if (o == "*") { total = a * Convert.ToDouble(InputBox.Text); }
                    else if (o == "/") { total = a / Convert.ToDouble(InputBox.Text); }
                    else if (o == "^") { total = Math.Pow(a, Convert.ToDouble(InputBox.Text)); }
                    else if (o == "R") { total = Math.Pow(a, 1 / Convert.ToDouble(InputBox.Text)); }

                    if (int.TryParse(InputBox.Text, out int n) || total >= 0)
                    {
                        InputBox.Text = total.ToString();
                    }
                    else
                    {
                        InputBox.Text = Math.Round(total, total.ToString().Length - 1).ToString();
                    }
                    
                }
                catch (Exception e)
                {
                    Console.WriteLine(e.Message);
                }


                if (input != "=")
                {
                    InputBox.Text = "";
                }
                else if (prev != "=")
                {
                    historyList.Items.Add(calculation + " ");
                    calculation = "";
                    Totals.Items.Add(total.ToString());
                    
                }
                    a = total;
                    o = input;
                



            }
            prev = input;
            //Console.WriteLine("{0},{1},{2},{3}", o, a, InputBox.Text, total);
        }

        //private void Number_Click(object sender) => InputBox.Text += Number.Text;

        //Simple = 460, 405
        //Scientific = 680, 405

        bool exp = false;

        private void ExpandButton_Click(object sender, EventArgs e)
        {
            if (exp) { this.Width += -3300; exp = false; }
            else { this.Width += 3300; exp = true; }
        }

        private void button1_Click(object sender, EventArgs e) => InputBox.Text += button1.Text;
        private void button2_Click(object sender, EventArgs e) => InputBox.Text += button2.Text;
        private void button3_Click(object sender, EventArgs e) => InputBox.Text += button3.Text;
        private void button4_Click(object sender, EventArgs e) => InputBox.Text += button4.Text;
        private void button5_Click(object sender, EventArgs e) => InputBox.Text += button5.Text;
        private void button6_Click(object sender, EventArgs e) => InputBox.Text += button6.Text;
        private void button7_Click(object sender, EventArgs e) => InputBox.Text += button7.Text;
        private void button8_Click(object sender, EventArgs e) => InputBox.Text += button8.Text;
        private void button9_Click(object sender, EventArgs e) => InputBox.Text += button9.Text;
        private void buttondot_Click(object sender, EventArgs e) => InputBox.Text += buttondot.Text;
        private void button0_Click(object sender, EventArgs e) => InputBox.Text += button0.Text;

        private void buttonClear_Click(object sender, EventArgs e) => Calculate("=");

        private void buttonEqual_Click(object sender, EventArgs e) => Calculate("+");

        private void buttonDiv_Click(object sender, EventArgs e) => Calculate("/");

        private void buttonMult_Click(object sender, EventArgs e) => Calculate("*");

        private void buttonMinus_Click(object sender, EventArgs e) => Calculate("-");

        public int flag = 4;

        private void timer1_Tick(object sender, EventArgs e)
        {
            label1.Text = calculation + " = " + total;

            if (operantCheck)
            {
                InputBox.Text = z.ToString();
                operantCheck = false;
            }
            double.TryParse(InputBox.Text, out z);
            try {
                int d;
                if (int.TryParse(DecText.Text, out d) && BaseTag == "dec")
                {
                    HexText.Text = Convert.ToString(d, 16);
                    OctText.Text = Convert.ToString(d, 8);
                    BinaryText.Text = Convert.ToString(d, 2);
                    flag = 4;
                }
                int dn = 0;
                int bc;
                int count = 0;
                bool isbase = true;
                if (int.TryParse(BinaryText.Text, out d) && BaseTag == "binary")
                {
                    foreach (char c in d.ToString().ToCharArray().Reverse<char>())
                    {
                        int.TryParse(c.ToString(), out bc);
                        Console.WriteLine(bc);
                        if (bc == 1 || bc == 0)
                        {
                            Console.WriteLine(Convert.ToInt32(Math.Pow(count, 2)) * bc);
                            dn += Convert.ToInt32(Math.Pow(count, 2)) * bc;
                            count++;
                        }
                        else { isbase = false; }
                    }
                    if (isbase)
                    {
                        HexText.Text = Convert.ToString(dn, 16);
                        OctText.Text = Convert.ToString(dn, 8);
                        DecText.Text = Convert.ToString(dn);
                        flag = 4;
                    }
                }
            }
            catch (Exception ex)
            { Console.WriteLine(ex.Message); }
        }

        private void buttonAC_Click(object sender, EventArgs e)
        {
            a = 0;
            total = 0;
            o = "";
            calculation = "";
            InputBox.Text = "";
            prev = "AC";
        }

        private void buttonC_Click(object sender, EventArgs e)
        {
            InputBox.Text = "";
            prev = "C";
        }

        private void viewToolStripMenuItem_Click(object sender, EventArgs e) { }

        private void historyToolStripMenuItem_Click(object sender, EventArgs e) => inter = "history";

        private void calculationsToolStripMenuItem_Click(object sender, EventArgs e) => inter = "calc";

        private void baseConversionToolStripMenuItem_Click(object sender, EventArgs e) => inter = "base";

        private void notesToolStripMenuItem_Click(object sender, EventArgs e) => inter = "notes";

        private void InterfaceChange_Tick(object sender, EventArgs e)
        {
            if(inter != previnter) { this.Width += 3300; exp = true; }
            previnter = inter;
            foreach(Control o in Controls)
            {
                if(o.Tag == inter)
                {
                    o.Visible = true;
                }
                else if(o.Tag != "simp")
                {
                    o.Visible = false;
                }
            }
        }

        private void BinaryLabel_Click(object sender, EventArgs e)
        {
            
            
        }

        private void Hexlabel_Click(object sender, EventArgs e)
        {
            
        }

        private void DecimalLabel_Click(object sender, EventArgs e)
        {
            
        }

        private void DecText_TextChanged(object sender, EventArgs e)
        {
            if (flag == 0) { BaseTag = "dec"; }
            flag--;
        }
        private void BinaryText_TextChanged(object sender, EventArgs e)
        {
            if (flag == 0) { BaseTag = "binary"; }
            flag--;
        }
        private void HexText_TextChanged(object sender, EventArgs e)
        {
            if (flag == 0) { BaseTag = "hex"; }
            flag--;
        }
        private void OctText_TextChanged(object sender, EventArgs e)
        {
            if (flag == 0) { BaseTag = "oct"; }
            flag--;
        }

        private void eventLog1_EntryWritten(object sender, System.Diagnostics.EntryWrittenEventArgs e)
        {

        }

        private void Totals_SelectedIndexChanged(object sender, EventArgs e)
        {
            InputBox.Text = Totals.SelectedItem.ToString();
        }

        private void historyToolStripMenuItem1_Click(object sender, EventArgs e)
        {
            Totals.Items.Clear();
            historyList.Items.Clear();
        }

        private void notesToolStripMenuItem1_Click(object sender, EventArgs e)
        {
            textBox1.Text = "";
        }

        private void calculationsToolStripMenuItem1_Click(object sender, EventArgs e)
        {
            a = 0;
            total = 0;
            o = "";
            calculation = "";
            InputBox.Text = "";
        }

        private void buttonPower_Click(object sender, EventArgs e) => Calculate("^");

        private void buttonLog_Click(object sender, EventArgs e) { if (prev != "=") { z = Math.Log(z); operantCheck = true; } }

        private void buttonFact_Click(object sender, EventArgs e) {
            if (prev != "=")
            {
                int t = 0;
                if (int.TryParse(z.ToString(), out int j))
                {
                    for (int i = 0; i < j; i++)
                    {
                        t = (j - i) * t;
                    }

                    z = t;
                    operantCheck = true;

                }
                else
                {
                    Console.WriteLine("Value must be an integer amount");
                }
            }
            
        }

        private void buttonRoot_Click(object sender, EventArgs e) => Calculate("R");

        private void buttonSin_Click(object sender, EventArgs e) { if (prev != "=") { z = Math.Sin(z); operantCheck = true; } }

        private void buttonCos_Click(object sender, EventArgs e) { if (prev != "=") { z = Math.Cos(z); operantCheck = true; } }

        private void buttonTan_Click(object sender, EventArgs e) { if (prev != "=") { z = Math.Tan(z); operantCheck = true; } }

        private void buttonAbs_Click(object sender, EventArgs e) { if (prev != "=") { z = Math.Abs(z); operantCheck = true; } }

        private void historyList_SelectedIndexChanged(object sender, EventArgs e)
        {

        }

        private void allToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Totals.Items.Clear();
            historyList.Items.Clear();
            a = 0;
            total = 0;
            o = "";
            calculation = "";
            InputBox.Text = "";
            textBox1.Text = "";
        }
    }
}
