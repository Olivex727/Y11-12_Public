﻿namespace OW_CYOA_Y11
{
    partial class Main
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            this.Input = new System.Windows.Forms.TextBox();
            this.InputButton = new System.Windows.Forms.Button();
            this.InputBack = new System.Windows.Forms.PictureBox();
            this.GT = new System.Windows.Forms.TextBox();
            this.txtsc = new System.Windows.Forms.Timer(this.components);
            this.label1 = new System.Windows.Forms.Label();
            this.autosave = new System.Windows.Forms.Timer(this.components);
            this.timer1 = new System.Windows.Forms.Timer(this.components);
            this.Stats = new System.Windows.Forms.TextBox();
            ((System.ComponentModel.ISupportInitialize)(this.InputBack)).BeginInit();
            this.SuspendLayout();
            // 
            // Input
            // 
            this.Input.Location = new System.Drawing.Point(13, 707);
            this.Input.Name = "Input";
            this.Input.Size = new System.Drawing.Size(1476, 22);
            this.Input.TabIndex = 0;
            // 
            // InputButton
            // 
            this.InputButton.Location = new System.Drawing.Point(1495, 706);
            this.InputButton.Name = "InputButton";
            this.InputButton.Size = new System.Drawing.Size(75, 23);
            this.InputButton.TabIndex = 1;
            this.InputButton.Text = "Enter";
            this.InputButton.UseVisualStyleBackColor = true;
            this.InputButton.Click += new System.EventHandler(this.InputButton_Click);
            // 
            // InputBack
            // 
            this.InputBack.BackColor = System.Drawing.SystemColors.ButtonHighlight;
            this.InputBack.Location = new System.Drawing.Point(-16, 694);
            this.InputBack.Name = "InputBack";
            this.InputBack.Size = new System.Drawing.Size(1642, 50);
            this.InputBack.TabIndex = 2;
            this.InputBack.TabStop = false;
            // 
            // GT
            // 
            this.GT.BackColor = System.Drawing.SystemColors.InactiveCaptionText;
            this.GT.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.GT.ForeColor = System.Drawing.SystemColors.Window;
            this.GT.Location = new System.Drawing.Point(13, 57);
            this.GT.Multiline = true;
            this.GT.Name = "GT";
            this.GT.ReadOnly = true;
            this.GT.Size = new System.Drawing.Size(1557, 631);
            this.GT.TabIndex = 3;
            // 
            // txtsc
            // 
            this.txtsc.Enabled = true;
            this.txtsc.Interval = 30;
            this.txtsc.Tick += new System.EventHandler(this.txtsc_Tick);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 16.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.ForeColor = System.Drawing.SystemColors.ControlLightLight;
            this.label1.Location = new System.Drawing.Point(1339, 22);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(222, 32);
            this.label1.TabIndex = 4;
            this.label1.Text = "Current Room: 0";
            // 
            // autosave
            // 
            this.autosave.Enabled = true;
            this.autosave.Interval = 1000;
            this.autosave.Tick += new System.EventHandler(this.autosave_Tick);
            // 
            // timer1
            // 
            this.timer1.Tick += new System.EventHandler(this.timer1_Tick);
            // 
            // Stats
            // 
            this.Stats.BackColor = System.Drawing.SystemColors.InactiveCaptionText;
            this.Stats.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Stats.ForeColor = System.Drawing.SystemColors.Window;
            this.Stats.Location = new System.Drawing.Point(13, 57);
            this.Stats.Multiline = true;
            this.Stats.Name = "Stats";
            this.Stats.ReadOnly = true;
            this.Stats.Size = new System.Drawing.Size(1557, 631);
            this.Stats.TabIndex = 5;
            this.Stats.Tag = "sts";
            this.Stats.Text = "rgergiergre";
            this.Stats.Visible = false;
            // 
            // Main
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.AutoSize = true;
            this.BackColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.ClientSize = new System.Drawing.Size(1582, 733);
            this.Controls.Add(this.Stats);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.GT);
            this.Controls.Add(this.InputButton);
            this.Controls.Add(this.Input);
            this.Controls.Add(this.InputBack);
            this.MaximizeBox = false;
            this.MaximumSize = new System.Drawing.Size(1600, 780);
            this.Name = "Main";
            this.Text = "Game";
            this.Load += new System.EventHandler(this.Main_Load);
            this.KeyDown += new System.Windows.Forms.KeyEventHandler(this.Main_KeyDown);
            ((System.ComponentModel.ISupportInitialize)(this.InputBack)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.TextBox Input;
        private System.Windows.Forms.Button InputButton;
        private System.Windows.Forms.PictureBox InputBack;
        private System.Windows.Forms.TextBox GT;
        public System.Windows.Forms.Timer txtsc;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Timer autosave;
        private System.Windows.Forms.Timer timer1;
        private System.Windows.Forms.TextBox Stats;
    }
}

