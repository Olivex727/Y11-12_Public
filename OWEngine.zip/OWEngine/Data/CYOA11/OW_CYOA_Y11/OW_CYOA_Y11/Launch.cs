﻿using System;
using System.IO;
//using System.IO;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace OW_CYOA_Y11
{
    public partial class Launch : Form
    {
        public string s = @"C:\\OWEngine";
        public string a = @"C:\\OWEngine/Data";
        public string b = @"C:\\OWEngine/Saves";
        public string c = @"C:\\OWEngine/Data/CYOA11";
        //Flag to check if user can create a file
        public bool create = true;

        public Launch()
        {
            InitializeComponent();
        }

        private void Launch_Load(object sender, EventArgs e)
        {
            //createFile();
            LoadToList();
        }

        public void LoadToList()
        {
            //Add all save files within CYOA11 to the ListBox
            try
            {
                SaveList.Items.Clear();
                foreach (string title in Directory.GetFiles(@"C:\\OWEngine/Saves/CYOA11", "*.txt"))
                {
                    SaveList.Items.Add(title);
                }
            }
            catch (Exception e)
            {
                Console.WriteLine(e.Message + ", loadtolist");
            }
        }

        //Create all directories and required operation files in C:
        public void createFile()
        {
            try
            {
                /*
                //Create main engine files
                if (!Directory.Exists(s))
                {
                    Directory.CreateDirectory(s);
                    Directory.CreateDirectory(a);
                    Directory.CreateDirectory(b);
                }
                //Create solution files
                */
                File.Create(@"C:\\OWEngine/Data/CYOA11/transfer.txt");

                
                /* Add Here the files that will be created and installed from online 
                * to Data/CYOA11 (e.g. json and text files for reading only) */
                
            }
            catch (Exception e)
            {
                Console.WriteLine(e.Message + ", createfile");
                MsgLabel.Text = "There was an error in creating files, you will not be able to save";
            }
        }

        //Set new game window
        public Main game = new Main();

        //Open the game window with no transfer settings
        private void MainButton_Click(object sender, EventArgs e)
        {
            WriteToTransfer("");
            game.Show();
            //this.Hide();
            
        }

        //Function on the LoadButton Event
        private void LoadButton_Click(object sender, EventArgs e)
        {
            try
            {
                string x = /*"C:\\OWEngine/Saves/CYOA11/" + */@""+SaveList.SelectedItem.ToString();
                WriteToTransfer(x);
                game.Show();
            }
            catch (Exception ex)
            {
                Console.WriteLine(ex.Message + ", loadbuttonclick");
            }
        }

        //Whenever the selected List item has changed
        private void SaveList_SelectedIndexChanged(object sender, EventArgs e)
        {
            try
            {
                if (SaveList.SelectedItem.ToString() == "Create New...")
                {
                    //LoadButton.Text = "New Save";
                }
                else
                {
                    LoadButton.Text = "Load Save";
                }
            }
            catch (Exception ex)
            {
                Console.WriteLine(ex.Message + ", savelist");
            }
        }

        //When the CreateFile button is pressed
        private void button1_Click(object sender, EventArgs e)
        {
            //Check if file can be created
            foreach(string s in SaveList.Items)
            {
                if(NameBox.Text == s)
                {
                    NameBox.Text = "Please enter proper file name";
                    create = false;
                }
            }
            //Create New file
            if (create)
            {
                string x = @"C:\\OWEngine/Saves/CYOA11/" + NameBox.Text + ".txt";
                try
                {
                    File.Create(x);
                }
                catch (Exception ex)
                {
                    Console.WriteLine(ex.Message + ", createbuttonclick");
                }
                //Refresh List
                LoadToList();
            }
            create = true;
        }

        //public 

        //Write the save path being used to transfer file
        public void WriteToTransfer(string p)
        {
            try
            {
                StreamWriter pathencoder = new StreamWriter(@"C:\\OWEngine/Data/CYOA11/transfer.txt");
                //pathencoder.C
                Console.WriteLine(p);
                pathencoder.WriteLine(p);
                pathencoder.Close();
            }
            catch (Exception e)
            {
                Console.WriteLine(e.Message + ", writetotransfer");
            }
        }

        public void LaunchTimer_Tick(object sender, EventArgs e)
        {
            if (game.IsDisposed)
            {
                game = new Main();
            }
        }
    }
}
