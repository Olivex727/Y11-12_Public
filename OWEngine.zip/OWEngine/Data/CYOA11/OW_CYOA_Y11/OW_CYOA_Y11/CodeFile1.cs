﻿/*
 * 
 * Get a Engine folder to be created if none is avalable
 * 
 * Engine
 * > Projects (Stores game types and assets)
 * > Saves (Stores the saved information with the game type at the top of the document)
 * 
 * Project file will store Read-only information to run (e.g. Json Objects, Text Dialouges)
 * Save file will store the saved data for each game (e.g. Locations, inventory and game types)
 * 
 * Using the Engine folder, it shold pe possible to run any c# projet from it that requires files
 * 
*/

/*
 * Stats that will be displayed:
 * 
 * Room Number
 * Options for that room
 * Rooms Travelled
 * Game Status (Completed or not)
 * Death Count
 * Time Played
 * 
 */

 /*
  * TO DO:
  * 
  * Add key commands
  * Read from Json and text for the main game
  * Write the game story
  */

  /*
   * IDEAS FOR ONLINE DOWNLOAD:
   * IP adress
   * APIs (for json)
   * using domains
   * 
   */