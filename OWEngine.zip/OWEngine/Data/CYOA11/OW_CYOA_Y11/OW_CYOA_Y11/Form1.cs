﻿using System;
using System.IO;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using Newtonsoft.Json;

namespace OW_CYOA_Y11
{
    public partial class Main : Form
    {
        public string cue = "";
        public int rotate = 0;
        public bool cuedone = true;
        public int room = 0;

        List<string> inventory = new List<string>();

        //Values to retreive from GetSave() and to use in autosave timer and Stats form
        public int timeplay = 0;
        public int deaths = 0;
        public bool game = false;
        public int traveled = 0;


        List<Room> rooms = new List<Room>();

        public Main()
        {
            InitializeComponent();
            

        }

        //Open a new Stats menu
        public bool inv = false;

        private void Main_Load(object sender, EventArgs e)
        {
            inventory.Add("");
            //KeyDown Function
            //this.KeyDown += Main_KeyDown;
            //Get the game dialouge, rooms and the save file stats in that order
            GetText();
            GetJson();
            GetSave();
            //If save not loaded, start from beginning
            if (room == 0) { LoadRoom("new"); }
        }

        //Event based on keypress
        private void Main_KeyDown(object sender, KeyEventArgs e)
        {
            Console.WriteLine("");
            Console.WriteLine(e.KeyCode);
            if(e.KeyCode == Keys.Escape)
            {
                this.Dispose();
            }
            if (e.KeyCode == Keys.Tab)
            {
                LoadRoom("stats");
            }
            if (e.KeyCode == Keys.Enter)
            {
                LoadRoom(Input.Text);
                Input.Text = "";
            }
        }

        //Loads an event based on the input from a user
        private void LoadRoom(string inp)
        {
            if(inp == "restart")
            {
                GT.Text = "";
                inp = "new";
            }
            //Load up room 0 at start of game
            if(inp == "new")
            {
                cuedone = true;
                foreach(Room r in rooms)
                {
                    if(r.id == 0)
                    {
                        cue = r.md;
                    }
                }
            }
            //Show Stats/Inventory Window
            if (inp == "stats")
            {
                Control t = new Control();
#pragma warning disable CS0252 // Possible unintended reference comparison; left hand side needs cast
                foreach (Control te in Controls) { if (te.Tag/*.ToString()*/ == "sts") { t = te; } }
#pragma warning restore CS0252 // Possible unintended reference comparison; left hand side needs cast

                if (inv)
                {
                    //invent.Dispose();
                    t.Visible = false;
                    inv = false;
                }
                else
                {
                    //invent.Show();
                    t.Visible = true;
                    inv = true;
                }    
            }

            string iv = "n";
            bool ro = false;
            int c = 0;
            //Changes Room Based on Options
            if (inp != "new")
            {
                foreach (Room r in rooms)
                {
                    //Console.WriteLine("Room {0}, {1}, {2}", r.id, room, room == r.id);
                    if (r.id == room && !cuedone)
                    {

                        foreach (string s in r.od)
                        {
                            //Console.WriteLine("{0}, {1}, {2}", s, inp, s == inp);
                            if (s == inp)
                            {
                                ro = true;
                                foreach (string i in inventory)
                                {
                                    try
                                    {
                                        if (i == r.oi[c]) { cuedone = true; if (i != "") { iv = "Used " + i + "\r\n"; } }
                                    }
                                    catch (Exception e)
                                    {
                                        Console.WriteLine(e.Message + ", invent algo");
                                        iv = "rn";
                                        cuedone = true;
                                    }
                                    
                                }
                                //label1.Text = "op = " + s + ", md = " + r.md + ", r = " + r.ops[c];
                            }
                            if (!cuedone) { c++; }
                        }
                        //Console.WriteLine(c +""+ r.ops[c]);
                        if (cuedone) { room = r.ops[c]; }

                    }


                }
                
                foreach (Room r in rooms)
                { 
                    /*Console.WriteLine("{0}, {1}, {2}", room, r.id, r.id == room);*/
                    if (r.id == room && cuedone) { cue = r.md; }
                }
            }

            //Repeat a line if input is wrong
            if (cuedone != true && inp != "stats")
            {
                foreach (Room r in rooms)
                {
                    /*Console.WriteLine("{0}, {1}, {2}", room, r.id, r.id == room);*/
                    if (r.id == room)
                    {
                        if (iv == "n" && ro) { cue = "Inventory item missing\r\n" + r.md; }
                        else { cue = r.md; }
                        cuedone = true;
                    }
                }
            }
            //Used to count transfered rooms, deaths (going back to room 0), and game ends (going to last room)
            else if (inp != "new" && inp != "stats")
            {
                traveled += 1;
                if (room == 0) { deaths += 1; }
                if (room == 3) { game = true; }
                foreach (Room r in rooms) { if (r.id == room && !inventory.Contains(r.item) && r.item != "") { inventory.Add(r.item); if (r.id != 1 && r.id != 0) { cue += "\r\nAdded: " + r.item + " to Inventory\r\n"; } } }
            }
            
        }

        //Allows the text to be printed on the screen in a timed manner
        public void txtsc_Tick(object sender, EventArgs e)
        {
            //int iei = 0;
            //foreach(string item in desc)
            //{
            //    Console.WriteLine(item + ", " + iei.ToString());
            //    iei++;
            //}
            string x = "";
            char[] txt = cue.ToCharArray();
            if (cuedone)
            {
                if (rotate < txt.Length)
                {
                    x += txt[rotate];
                    rotate++;
                }
                else
                {
                    cue = "";
                    cuedone = false;
                    rotate = 0;
                    GT.Text += "\r\n";
                }
            }
            GT.Text += x;

            label1.Text = "Current Room: " + room.ToString();
        }

        //Sends input after pressing the button labeled "Enter"
        private void InputButton_Click(object sender, EventArgs e)
        {
            if (Input.Text != "new")
            {
                LoadRoom(Input.Text);
                Input.Text = "";
            }
            else
            {
                LoadRoom("newm");
                Input.Text = "";
            }
            GT.Text += "\r\n";
        }

        public string[] desc = new string[] { };

        //Gets the multiple text documents
        public void GetText()
        {
            try
            {
                string[] j;
                using (StreamReader f = new StreamReader(@"C:\\OWEngine/Data/CYOA11/desc.txt"))
                {
                    j = f.ReadToEnd().Split('>');
                    int c = 0;
                    desc = new string[j.Length];
                    foreach (string line in j)
                    {
                        if (c % 2 == 0) { desc[c/2] = line; }
                        c++;
                    }
                }
            }
            catch (Exception e)
            {
                Console.WriteLine(e.Message + ", GetText");
            }
            //desc = new string[] { "LOL, rnefnvkkrd", "fgfdg", "sdgnjd", "urbicue" };
        }

        //Gets the multiple json documents
        public void GetJson()
        {
            try
            {
                string j = "";
                using (StreamReader f = new StreamReader(@"C:\\OWEngine/Data/CYOA11/rooms.json"))
                {
                    JsonSerializer s = new JsonSerializer();
                    j = f.ReadToEnd();
                    rooms = JsonConvert.DeserializeObject<List<Room>>(j);
                    f.Close();
                }
                foreach(Room r in rooms)
                {
                    r.md = desc[r.id];
                }
            }
            catch (Exception e)
            {
                Console.WriteLine(e.Message + ", GetJson");
            }
            /*
            Room room0 = new Room()
            {
                id = 0,
                md = desc[0],
                ops = new int[] { 1, 3 },
                od = new string[] {"1", "3"},
                oi = new string[] {"", "o"}
            };
            Room room2 = new Room()
            {
                id = 2,
                md = desc[2],
                ops = new int[] { 0, 3 },
                od = new string[] { "0", "3" },
                item = "o"
            };
            Room room3 = new Room()
            {
                id = 3,
                md = desc[3],
                ops = new int[] { 1, 0 },
                od = new string[] { "1", "0" }
            };
            Room room1 = new Room()
            {
                id = 1,
                md = desc[1],
                ops = new int[] { 2, 3 },
                od = new string[] { "2", "3" },
                oi = new string[] { "", "o" }
            };
            rooms.Add(room1);
            rooms.Add(room2);
            rooms.Add(room3);
            rooms.Add(room0);
            */
        }

        public string p;

        //Autosave Files
        private void autosave_Tick(object sender, EventArgs e)
        {
            timeplay += 1;
            string i = "";
            string x = "";
            foreach(Room r in rooms)
            {
                if(r.id == room)
                {
                    foreach(string s in r.od)
                    {
                        if (s != r.od[r.od.Length-1]) { x += s + ", "; } else { x += s; }
                    }
                }
            }
            int l = 0;
            foreach (string s in inventory)
            {
                if (l != inventory.Count) { i += s + ", "; } else { i += s; }
                //Clean inventory of blank items
            }
            try
            {
                /*public int timeplay = 0;
                public int deaths = 0;
                public bool game = false;
                public int traveled = 0;*/
                StreamWriter save = new StreamWriter(@p);
                save.WriteLine(

                    room.ToString() + "\n" +
                    x + "\n" +
                    traveled.ToString() + "\n" +
                    game.ToString() + "\n" +
                    deaths.ToString() + "\n" +
                    timeplay.ToString() + "\n" +
                    i
                    );
                save.Close();
            }
            catch (Exception ex)
            {
                Console.WriteLine(ex.Message + ", " + ex.ToString() + ", autosave");
            }
            updateStats();
        }


        //Gets the saved information from a loaded file (and stats to add onto)
        public void GetSave()
        {
            try
            {
                StreamReader transfer = new StreamReader(@"C:\\OWEngine/Data/CYOA11/transfer.txt");

                p = transfer.ReadLine();

                transfer.Close();

                StreamReader save = new StreamReader(@p);

                /*room.ToString() + "\n" +
                x + "\n" +
                traveled.ToString() + "\n" +
                game.ToString() + "\n" +
                deaths.ToString() + "\n" +
                timeplay.ToString()*/

                //Save stats to values
                string s = save.ReadLine();
                if (s == "" || !int.TryParse(s, out room)){ room = 0; }
                save.ReadLine();
                s = save.ReadLine();
                if (s == "" || !int.TryParse(s, out traveled)) { traveled = 0; }
                s = save.ReadLine();
                if (s == "" || !bool.TryParse(s, out game)) { game = false; }
                s = save.ReadLine();
                if (s == "" || !int.TryParse(s, out deaths)) { deaths = 0; }
                s = save.ReadLine();
                if (s == "" || !int.TryParse(s, out timeplay)) { timeplay = 0; }
                s = save.ReadLine();
                try
                {
                    inventory = s.Split(',', ' ').ToList<string>();
                }
                catch (Exception e)
                {
                    Console.WriteLine(e.Message + ", GetSave (invent)");
                    //inventory.Add("");
                }


                //

                save.Close();

                if (room != 0)
                {
                    foreach (Room r in rooms)
                    {
                        /*Console.WriteLine("{0}, {1}, {2}", room, r.id, r.id == room);*/
                        if (r.id == room) { cue = r.md; cuedone = true; }
                    }

                }
            }
            catch (Exception e)
            {
                Console.WriteLine(e.Message + ", getsave");
            }
        }

        public void updateStats()
        {
            try
            {

                StreamReader transfer = new StreamReader(@"C:\\OWEngine/Data/CYOA11/transfer.txt");

                p = transfer.ReadLine();

                transfer.Close();

                StreamReader save = new StreamReader(@p);

                /*room.ToString() + "\n" +
                x + "\n" +
                traveled.ToString() + "\n" +
                game.ToString() + "\n" +
                deaths.ToString() + "\n" +
                timeplay.ToString()*/

                //Write stats to the text box
                Stats.Text =
                    "Room Number: " + save.ReadLine() + "\r\n" +
                    "Room Options: " + save.ReadLine() + "\r\n" +
                    "Rooms Travelled to: " + save.ReadLine() + "\r\n" +
                    "Game Won: " + save.ReadLine() + "\r\n" +
                    "Deaths: " + save.ReadLine() + "\r\n" +
                    "Time Spent Playing: " + save.ReadLine() + " seconds" + "\r\n" +
                    "Inventory: " + save.ReadLine() + "\r\n"
                    ;

                save.Close();
            }
            catch (Exception ex)
            {
                Console.WriteLine(ex.Message + ", Refresh Timer");
                Stats.Text = "You can only view stats on saved games";
            }
        }

        private void timer1_Tick(object sender, EventArgs e)
        {

        }

        private void Main_KeyPress(object sender, KeyPressEventArgs e)
        {
            //if(e. == Keys)
        }
    }
    //The main room class
    public class Room
    {
        //id No. of room
        public int id { get; set; }
        
        //Worded description of room
        public string md { get; set; }

        //Array of options and choices for room (index is opt. No. and value is room to go to
        public int[] ops { get; set; }

        //Array of descriptions for the options (Moves story to room)
        public string[] od { get; set; }

        //Inventory Requirements for each option
        public string[] oi { get; set; }

        //Inventory Added at start of room
        public string item { get; set; }
    }
}
