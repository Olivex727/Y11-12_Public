﻿using System;
using System.IO;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace OW_CYOA_Y11
{
    public partial class Stats : Form
    {
        public Stats()
        {
            InitializeComponent();
        }

        private void Stats_Load(object sender, EventArgs e)
        {
            //LoadStats();
        }

        //Refreshes the Stats
        public void LoadStats()
        {
            try
            {
                StreamReader transfer = new StreamReader(@"C:\\OWEngine/Data/CYOA11/transfer.txt");

                string p = transfer.ReadLine();

                transfer.Close();

                StreamReader save = new StreamReader(@p);

                /*room.ToString() + "\n" +
                x + "\n" +
                traveled.ToString() + "\n" +
                game.ToString() + "\n" +
                deaths.ToString() + "\n" +
                timeplay.ToString()*/

                //Write stats to the text box
                InfoBox.Text =
                    "Room Number: " + save.ReadLine() + "\r\n" +
                    "Room Options: " + save.ReadLine() + "\r\n" +
                    "Rooms Travelled to: " + save.ReadLine() + "\r\n" +
                    "Game Won: " + save.ReadLine() + "\r\n" +
                    "Deaths: " + save.ReadLine() + "\r\n" +
                    "Time Spent Playing: " + save.ReadLine() + " seconds" + "\r\n" +
                    "Inventory: " + save.ReadLine() + "\r\n"
                    ;

                save.Close();
            }
            catch (Exception ex)
            {
                Console.WriteLine(ex.Message + ", Load To Stats");
                InfoBox.Text = "You can only view stats on saved games";
            }
        }

        //Refrest Timer ticks when the stats need to be reset
        private void RefreshTimer_Tick(object sender, EventArgs e)
        {
            //LoadStats();
        }
    }
}
