﻿namespace TradeGame
{
    partial class TradeGame
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(TradeGame));
            this.Map = new System.Windows.Forms.PictureBox();
            this.Menu = new System.Windows.Forms.MenuStrip();
            this.optionsToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.saveGameToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.loadGameToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.quitToTitleToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.dashboardToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.mainPortfolioToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.materialsToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.marketToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.travelToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.GameCheck = new System.Windows.Forms.Timer(this.components);
            this.title = new System.Windows.Forms.Label();
            this.bck = new System.Windows.Forms.PictureBox();
            this.NGlabel = new System.Windows.Forms.Label();
            this.LGlabel = new System.Windows.Forms.Label();
            this.CredLabel = new System.Windows.Forms.Label();
            this.QLabel = new System.Windows.Forms.Label();
            this.GameList = new System.Windows.Forms.ListBox();
            this.textBox1 = new System.Windows.Forms.TextBox();
            this.TurnButton = new System.Windows.Forms.Button();
            this.TL = new System.Windows.Forms.Label();
            this.IntfTimer = new System.Windows.Forms.Timer(this.components);
            this.GameTitle = new System.Windows.Forms.Label();
            this.ML = new System.Windows.Forms.Label();
            this.LocL = new System.Windows.Forms.Label();
            this.Help = new System.Windows.Forms.Label();
            this.MatBox1 = new System.Windows.Forms.ListBox();
            this.MatSel = new System.Windows.Forms.NumericUpDown();
            this.MatAdd = new System.Windows.Forms.Button();
            this.MatLabel = new System.Windows.Forms.Label();
            this.MatBox2 = new System.Windows.Forms.ListBox();
            this.MatBox3 = new System.Windows.Forms.ListBox();
            this.MatBox4 = new System.Windows.Forms.ListBox();
            this.TB = new System.Windows.Forms.Button();
            this.CL = new System.Windows.Forms.Label();
            this.pfo = new System.Windows.Forms.TextBox();
            this.CheckOver = new System.Windows.Forms.Timer(this.components);
            ((System.ComponentModel.ISupportInitialize)(this.Map)).BeginInit();
            this.Menu.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.bck)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.MatSel)).BeginInit();
            this.SuspendLayout();
            // 
            // Map
            // 
            this.Map.BackColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.Map.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Center;
            this.Map.Image = ((System.Drawing.Image)(resources.GetObject("Map.Image")));
            this.Map.Location = new System.Drawing.Point(35, 43);
            this.Map.Name = "Map";
            this.Map.Size = new System.Drawing.Size(1535, 798);
            this.Map.TabIndex = 0;
            this.Map.TabStop = false;
            this.Map.Tag = "map";
            this.Map.Click += new System.EventHandler(this.Map_Click);
            this.Map.MouseClick += new System.Windows.Forms.MouseEventHandler(this.Map_MouseClick);
            // 
            // Menu
            // 
            this.Menu.ImageScalingSize = new System.Drawing.Size(20, 20);
            this.Menu.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.optionsToolStripMenuItem,
            this.dashboardToolStripMenuItem});
            this.Menu.Location = new System.Drawing.Point(0, 0);
            this.Menu.Name = "Menu";
            this.Menu.Size = new System.Drawing.Size(1582, 28);
            this.Menu.TabIndex = 1;
            this.Menu.Tag = "";
            this.Menu.Text = "Menu";
            // 
            // optionsToolStripMenuItem
            // 
            this.optionsToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.saveGameToolStripMenuItem,
            this.loadGameToolStripMenuItem,
            this.quitToTitleToolStripMenuItem});
            this.optionsToolStripMenuItem.Name = "optionsToolStripMenuItem";
            this.optionsToolStripMenuItem.Size = new System.Drawing.Size(73, 24);
            this.optionsToolStripMenuItem.Text = "Options";
            // 
            // saveGameToolStripMenuItem
            // 
            this.saveGameToolStripMenuItem.Name = "saveGameToolStripMenuItem";
            this.saveGameToolStripMenuItem.Size = new System.Drawing.Size(160, 26);
            this.saveGameToolStripMenuItem.Text = "Save Game";
            this.saveGameToolStripMenuItem.Click += new System.EventHandler(this.saveGameToolStripMenuItem_Click);
            // 
            // loadGameToolStripMenuItem
            // 
            this.loadGameToolStripMenuItem.Name = "loadGameToolStripMenuItem";
            this.loadGameToolStripMenuItem.Size = new System.Drawing.Size(160, 26);
            this.loadGameToolStripMenuItem.Text = "Load Game";
            this.loadGameToolStripMenuItem.Click += new System.EventHandler(this.loadGameToolStripMenuItem_Click);
            // 
            // quitToTitleToolStripMenuItem
            // 
            this.quitToTitleToolStripMenuItem.Name = "quitToTitleToolStripMenuItem";
            this.quitToTitleToolStripMenuItem.Size = new System.Drawing.Size(160, 26);
            this.quitToTitleToolStripMenuItem.Text = "Title";
            this.quitToTitleToolStripMenuItem.Click += new System.EventHandler(this.quitToTitleToolStripMenuItem_Click);
            // 
            // dashboardToolStripMenuItem
            // 
            this.dashboardToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.mainPortfolioToolStripMenuItem,
            this.materialsToolStripMenuItem,
            this.marketToolStripMenuItem,
            this.travelToolStripMenuItem});
            this.dashboardToolStripMenuItem.Name = "dashboardToolStripMenuItem";
            this.dashboardToolStripMenuItem.Size = new System.Drawing.Size(94, 24);
            this.dashboardToolStripMenuItem.Text = "Dashboard";
            // 
            // mainPortfolioToolStripMenuItem
            // 
            this.mainPortfolioToolStripMenuItem.Name = "mainPortfolioToolStripMenuItem";
            this.mainPortfolioToolStripMenuItem.Size = new System.Drawing.Size(145, 26);
            this.mainPortfolioToolStripMenuItem.Text = "Portfolio";
            this.mainPortfolioToolStripMenuItem.Click += new System.EventHandler(this.mainPortfolioToolStripMenuItem_Click);
            // 
            // materialsToolStripMenuItem
            // 
            this.materialsToolStripMenuItem.Name = "materialsToolStripMenuItem";
            this.materialsToolStripMenuItem.Size = new System.Drawing.Size(145, 26);
            this.materialsToolStripMenuItem.Text = "Materials";
            this.materialsToolStripMenuItem.Click += new System.EventHandler(this.materialsToolStripMenuItem_Click);
            // 
            // marketToolStripMenuItem
            // 
            this.marketToolStripMenuItem.Name = "marketToolStripMenuItem";
            this.marketToolStripMenuItem.Size = new System.Drawing.Size(145, 26);
            this.marketToolStripMenuItem.Text = "Market";
            this.marketToolStripMenuItem.Click += new System.EventHandler(this.marketToolStripMenuItem_Click);
            // 
            // travelToolStripMenuItem
            // 
            this.travelToolStripMenuItem.Name = "travelToolStripMenuItem";
            this.travelToolStripMenuItem.Size = new System.Drawing.Size(145, 26);
            this.travelToolStripMenuItem.Text = "Travel";
            this.travelToolStripMenuItem.Click += new System.EventHandler(this.travelToolStripMenuItem_Click);
            // 
            // GameCheck
            // 
            this.GameCheck.Enabled = true;
            this.GameCheck.Interval = 1;
            this.GameCheck.Tick += new System.EventHandler(this.GameCheck_Tick);
            // 
            // title
            // 
            this.title.AutoSize = true;
            this.title.BackColor = System.Drawing.Color.Gray;
            this.title.Font = new System.Drawing.Font("Franklin Gothic Medium", 25.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.title.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.title.ImageAlign = System.Drawing.ContentAlignment.TopLeft;
            this.title.Location = new System.Drawing.Point(108, 98);
            this.title.Name = "title";
            this.title.Size = new System.Drawing.Size(561, 50);
            this.title.TabIndex = 2;
            this.title.Tag = "title";
            this.title.Text = "Oliver Walters\' Trading Game";
            this.title.Click += new System.EventHandler(this.title_Click);
            // 
            // bck
            // 
            this.bck.BackColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.bck.Image = ((System.Drawing.Image)(resources.GetObject("bck.Image")));
            this.bck.Location = new System.Drawing.Point(-12, 0);
            this.bck.Name = "bck";
            this.bck.Size = new System.Drawing.Size(1601, 862);
            this.bck.TabIndex = 3;
            this.bck.TabStop = false;
            this.bck.Tag = "title";
            // 
            // NGlabel
            // 
            this.NGlabel.AutoSize = true;
            this.NGlabel.BackColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.NGlabel.Font = new System.Drawing.Font("Franklin Gothic Medium", 18F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.NGlabel.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.NGlabel.Location = new System.Drawing.Point(110, 290);
            this.NGlabel.Name = "NGlabel";
            this.NGlabel.Size = new System.Drawing.Size(159, 38);
            this.NGlabel.TabIndex = 4;
            this.NGlabel.Tag = "title";
            this.NGlabel.Text = "New Game";
            this.NGlabel.Click += new System.EventHandler(this.NGlabel_Click);
            // 
            // LGlabel
            // 
            this.LGlabel.AutoSize = true;
            this.LGlabel.BackColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.LGlabel.Font = new System.Drawing.Font("Franklin Gothic Medium", 18F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.LGlabel.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.LGlabel.Location = new System.Drawing.Point(110, 365);
            this.LGlabel.Name = "LGlabel";
            this.LGlabel.Size = new System.Drawing.Size(165, 38);
            this.LGlabel.TabIndex = 5;
            this.LGlabel.Tag = "title";
            this.LGlabel.Text = "Load Game";
            this.LGlabel.Click += new System.EventHandler(this.LGlabel_Click);
            // 
            // CredLabel
            // 
            this.CredLabel.AutoSize = true;
            this.CredLabel.BackColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.CredLabel.Font = new System.Drawing.Font("Franklin Gothic Medium", 18F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.CredLabel.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.CredLabel.Location = new System.Drawing.Point(110, 437);
            this.CredLabel.Name = "CredLabel";
            this.CredLabel.Size = new System.Drawing.Size(107, 38);
            this.CredLabel.TabIndex = 6;
            this.CredLabel.Tag = "title";
            this.CredLabel.Text = "Credits";
            this.CredLabel.Click += new System.EventHandler(this.CredLabel_Click);
            // 
            // QLabel
            // 
            this.QLabel.AutoSize = true;
            this.QLabel.BackColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.QLabel.Font = new System.Drawing.Font("Franklin Gothic Medium", 18F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.QLabel.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.QLabel.Location = new System.Drawing.Point(110, 511);
            this.QLabel.Name = "QLabel";
            this.QLabel.Size = new System.Drawing.Size(69, 38);
            this.QLabel.TabIndex = 7;
            this.QLabel.Tag = "title";
            this.QLabel.Text = "Ouit";
            this.QLabel.Click += new System.EventHandler(this.QLabel_Click);
            // 
            // GameList
            // 
            this.GameList.BackColor = System.Drawing.Color.Gray;
            this.GameList.Font = new System.Drawing.Font("Franklin Gothic Medium", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.GameList.ForeColor = System.Drawing.SystemColors.Window;
            this.GameList.FormattingEnabled = true;
            this.GameList.ItemHeight = 29;
            this.GameList.Items.AddRange(new object[] {
            "Nrfe",
            "rggrgr"});
            this.GameList.Location = new System.Drawing.Point(443, 290);
            this.GameList.Name = "GameList";
            this.GameList.ScrollAlwaysVisible = true;
            this.GameList.Size = new System.Drawing.Size(724, 381);
            this.GameList.TabIndex = 8;
            this.GameList.Tag = "load";
            this.GameList.SelectedIndexChanged += new System.EventHandler(this.GameList_SelectedIndexChanged);
            // 
            // textBox1
            // 
            this.textBox1.Font = new System.Drawing.Font("Franklin Gothic Medium", 16.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.textBox1.Location = new System.Drawing.Point(443, 290);
            this.textBox1.Name = "textBox1";
            this.textBox1.Size = new System.Drawing.Size(724, 38);
            this.textBox1.TabIndex = 9;
            this.textBox1.Tag = "new";
            this.textBox1.TextChanged += new System.EventHandler(this.textBox1_TextChanged);
            // 
            // TurnButton
            // 
            this.TurnButton.Location = new System.Drawing.Point(1415, 789);
            this.TurnButton.Name = "TurnButton";
            this.TurnButton.Size = new System.Drawing.Size(155, 52);
            this.TurnButton.TabIndex = 10;
            this.TurnButton.Tag = "game";
            this.TurnButton.Text = "End Turn";
            this.TurnButton.UseVisualStyleBackColor = true;
            this.TurnButton.Click += new System.EventHandler(this.TurnButton_Click);
            // 
            // TL
            // 
            this.TL.AutoSize = true;
            this.TL.BackColor = System.Drawing.SystemColors.Menu;
            this.TL.Font = new System.Drawing.Font("Franklin Gothic Medium", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.TL.Location = new System.Drawing.Point(1433, 0);
            this.TL.Name = "TL";
            this.TL.Size = new System.Drawing.Size(137, 25);
            this.TL.TabIndex = 11;
            this.TL.Tag = "fgame";
            this.TL.Text = "Time: 0.0 days";
            // 
            // IntfTimer
            // 
            this.IntfTimer.Interval = 10;
            this.IntfTimer.Tick += new System.EventHandler(this.IntfTimer_Tick);
            // 
            // GameTitle
            // 
            this.GameTitle.AutoSize = true;
            this.GameTitle.BackColor = System.Drawing.Color.Transparent;
            this.GameTitle.Font = new System.Drawing.Font("Franklin Gothic Medium", 25.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.GameTitle.ForeColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.GameTitle.Location = new System.Drawing.Point(108, 98);
            this.GameTitle.Name = "GameTitle";
            this.GameTitle.Size = new System.Drawing.Size(181, 50);
            this.GameTitle.TabIndex = 12;
            this.GameTitle.Tag = "game";
            this.GameTitle.Text = "Portfolio";
            // 
            // ML
            // 
            this.ML.AutoSize = true;
            this.ML.BackColor = System.Drawing.Color.Transparent;
            this.ML.Font = new System.Drawing.Font("Franklin Gothic Medium", 10.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.ML.ForeColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.ML.Location = new System.Drawing.Point(426, 680);
            this.ML.Name = "ML";
            this.ML.Size = new System.Drawing.Size(296, 24);
            this.ML.TabIndex = 13;
            this.ML.Tag = "mat";
            this.ML.Text = "Add/Remove Items from inventory:";
            // 
            // LocL
            // 
            this.LocL.AutoSize = true;
            this.LocL.BackColor = System.Drawing.SystemColors.Menu;
            this.LocL.Font = new System.Drawing.Font("Franklin Gothic Medium", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.LocL.Location = new System.Drawing.Point(1198, 0);
            this.LocL.Name = "LocL";
            this.LocL.Size = new System.Drawing.Size(158, 25);
            this.LocL.TabIndex = 14;
            this.LocL.Tag = "fgame";
            this.LocL.Text = "Location: Central";
            // 
            // Help
            // 
            this.Help.AutoSize = true;
            this.Help.BackColor = System.Drawing.SystemColors.Menu;
            this.Help.Font = new System.Drawing.Font("Franklin Gothic Medium", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Help.Location = new System.Drawing.Point(312, 0);
            this.Help.Name = "Help";
            this.Help.Size = new System.Drawing.Size(158, 25);
            this.Help.TabIndex = 15;
            this.Help.Tag = "fgame";
            this.Help.Text = "Location: Central";
            // 
            // MatBox1
            // 
            this.MatBox1.BackColor = System.Drawing.SystemColors.Info;
            this.MatBox1.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.MatBox1.ForeColor = System.Drawing.SystemColors.InactiveCaptionText;
            this.MatBox1.FormattingEnabled = true;
            this.MatBox1.ItemHeight = 25;
            this.MatBox1.Location = new System.Drawing.Point(99, 242);
            this.MatBox1.Name = "MatBox1";
            this.MatBox1.Size = new System.Drawing.Size(279, 429);
            this.MatBox1.TabIndex = 16;
            this.MatBox1.Tag = "mat";
            this.MatBox1.SelectedIndexChanged += new System.EventHandler(this.MatBox_SelectedIndexChanged);
            // 
            // MatSel
            // 
            this.MatSel.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.MatSel.Location = new System.Drawing.Point(741, 677);
            this.MatSel.Name = "MatSel";
            this.MatSel.Size = new System.Drawing.Size(120, 27);
            this.MatSel.TabIndex = 17;
            this.MatSel.Tag = "mat";
            this.MatSel.ValueChanged += new System.EventHandler(this.MatSel_ValueChanged);
            // 
            // MatAdd
            // 
            this.MatAdd.Location = new System.Drawing.Point(867, 677);
            this.MatAdd.Name = "MatAdd";
            this.MatAdd.Size = new System.Drawing.Size(108, 27);
            this.MatAdd.TabIndex = 18;
            this.MatAdd.Tag = "mat";
            this.MatAdd.Text = "Add/Remove";
            this.MatAdd.UseVisualStyleBackColor = true;
            this.MatAdd.Click += new System.EventHandler(this.MatAdd_Click);
            // 
            // MatLabel
            // 
            this.MatLabel.AutoSize = true;
            this.MatLabel.BackColor = System.Drawing.Color.Transparent;
            this.MatLabel.Font = new System.Drawing.Font("Franklin Gothic Medium", 10.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.MatLabel.ForeColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.MatLabel.Location = new System.Drawing.Point(99, 215);
            this.MatLabel.Name = "MatLabel";
            this.MatLabel.Size = new System.Drawing.Size(747, 24);
            this.MatLabel.TabIndex = 19;
            this.MatLabel.Tag = "mat";
            this.MatLabel.Text = "#  Materials (Net Worth):     Cost | Amount                   Inflation | Anchor " +
    "               Inventory";
            // 
            // MatBox2
            // 
            this.MatBox2.BackColor = System.Drawing.SystemColors.Info;
            this.MatBox2.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.MatBox2.ForeColor = System.Drawing.SystemColors.InactiveCaptionText;
            this.MatBox2.FormattingEnabled = true;
            this.MatBox2.ItemHeight = 25;
            this.MatBox2.Location = new System.Drawing.Point(377, 242);
            this.MatBox2.Name = "MatBox2";
            this.MatBox2.SelectionMode = System.Windows.Forms.SelectionMode.None;
            this.MatBox2.Size = new System.Drawing.Size(238, 429);
            this.MatBox2.TabIndex = 20;
            this.MatBox2.Tag = "mat";
            // 
            // MatBox3
            // 
            this.MatBox3.BackColor = System.Drawing.SystemColors.Info;
            this.MatBox3.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.MatBox3.ForeColor = System.Drawing.SystemColors.InactiveCaptionText;
            this.MatBox3.FormattingEnabled = true;
            this.MatBox3.ItemHeight = 25;
            this.MatBox3.Location = new System.Drawing.Point(614, 242);
            this.MatBox3.Name = "MatBox3";
            this.MatBox3.SelectionMode = System.Windows.Forms.SelectionMode.None;
            this.MatBox3.Size = new System.Drawing.Size(238, 429);
            this.MatBox3.TabIndex = 21;
            this.MatBox3.Tag = "mat";
            // 
            // MatBox4
            // 
            this.MatBox4.BackColor = System.Drawing.SystemColors.Info;
            this.MatBox4.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.MatBox4.ForeColor = System.Drawing.SystemColors.InactiveCaptionText;
            this.MatBox4.FormattingEnabled = true;
            this.MatBox4.ItemHeight = 25;
            this.MatBox4.Location = new System.Drawing.Point(851, 242);
            this.MatBox4.Name = "MatBox4";
            this.MatBox4.SelectionMode = System.Windows.Forms.SelectionMode.None;
            this.MatBox4.Size = new System.Drawing.Size(238, 429);
            this.MatBox4.TabIndex = 22;
            this.MatBox4.Tag = "mat";
            // 
            // TB
            // 
            this.TB.Location = new System.Drawing.Point(981, 677);
            this.TB.Name = "TB";
            this.TB.Size = new System.Drawing.Size(108, 27);
            this.TB.TabIndex = 23;
            this.TB.Tag = "market";
            this.TB.Text = "Toggle";
            this.TB.UseVisualStyleBackColor = true;
            this.TB.Click += new System.EventHandler(this.TB_Click);
            // 
            // CL
            // 
            this.CL.AutoSize = true;
            this.CL.BackColor = System.Drawing.SystemColors.Menu;
            this.CL.Font = new System.Drawing.Font("Franklin Gothic Medium", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.CL.Location = new System.Drawing.Point(953, 0);
            this.CL.Name = "CL";
            this.CL.Size = new System.Drawing.Size(155, 25);
            this.CL.TabIndex = 24;
            this.CL.Tag = "fgame";
            this.CL.Text = "Currency: Money";
            // 
            // pfo
            // 
            this.pfo.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(192)))));
            this.pfo.Font = new System.Drawing.Font("Franklin Gothic Medium", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.pfo.Location = new System.Drawing.Point(99, 242);
            this.pfo.Multiline = true;
            this.pfo.Name = "pfo";
            this.pfo.ReadOnly = true;
            this.pfo.Size = new System.Drawing.Size(990, 429);
            this.pfo.TabIndex = 25;
            this.pfo.Tag = "main";
            // 
            // CheckOver
            // 
            this.CheckOver.Interval = 10;
            this.CheckOver.Tick += new System.EventHandler(this.CheckOver_Tick);
            // 
            // TradeGame
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.Azure;
            this.ClientSize = new System.Drawing.Size(1582, 853);
            this.ControlBox = false;
            this.Controls.Add(this.CL);
            this.Controls.Add(this.TB);
            this.Controls.Add(this.MatLabel);
            this.Controls.Add(this.MatAdd);
            this.Controls.Add(this.MatSel);
            this.Controls.Add(this.Help);
            this.Controls.Add(this.LocL);
            this.Controls.Add(this.ML);
            this.Controls.Add(this.GameTitle);
            this.Controls.Add(this.TL);
            this.Controls.Add(this.TurnButton);
            this.Controls.Add(this.textBox1);
            this.Controls.Add(this.GameList);
            this.Controls.Add(this.QLabel);
            this.Controls.Add(this.CredLabel);
            this.Controls.Add(this.LGlabel);
            this.Controls.Add(this.NGlabel);
            this.Controls.Add(this.title);
            this.Controls.Add(this.Menu);
            this.Controls.Add(this.bck);
            this.Controls.Add(this.Map);
            this.Controls.Add(this.pfo);
            this.Controls.Add(this.MatBox2);
            this.Controls.Add(this.MatBox1);
            this.Controls.Add(this.MatBox3);
            this.Controls.Add(this.MatBox4);
            this.MainMenuStrip = this.Menu;
            this.MaximizeBox = false;
            this.MaximumSize = new System.Drawing.Size(1600, 900);
            this.MinimumSize = new System.Drawing.Size(1600, 900);
            this.Name = "TradeGame";
            this.Text = "OW TradeGame";
            this.Load += new System.EventHandler(this.Main_Load);
            ((System.ComponentModel.ISupportInitialize)(this.Map)).EndInit();
            this.Menu.ResumeLayout(false);
            this.Menu.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.bck)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.MatSel)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.PictureBox Map;
        private System.Windows.Forms.MenuStrip Menu;
        private System.Windows.Forms.ToolStripMenuItem optionsToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem saveGameToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem loadGameToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem quitToTitleToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem dashboardToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem mainPortfolioToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem materialsToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem marketToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem travelToolStripMenuItem;
        private System.Windows.Forms.Timer GameCheck;
        private System.Windows.Forms.Label title;
        private System.Windows.Forms.PictureBox bck;
        private System.Windows.Forms.Label NGlabel;
        private System.Windows.Forms.Label LGlabel;
        private System.Windows.Forms.Label CredLabel;
        private System.Windows.Forms.Label QLabel;
        private System.Windows.Forms.ListBox GameList;
        private System.Windows.Forms.TextBox textBox1;
        private System.Windows.Forms.Button TurnButton;
        private System.Windows.Forms.Label TL;
        public System.Windows.Forms.Timer IntfTimer;
        private System.Windows.Forms.Label GameTitle;
        private System.Windows.Forms.Label ML;
        private System.Windows.Forms.Label LocL;
        private System.Windows.Forms.Label Help;
        public System.Windows.Forms.ListBox MatBox1;
        private System.Windows.Forms.Button MatAdd;
        private System.Windows.Forms.Label MatLabel;
        public System.Windows.Forms.ListBox MatBox2;
        public System.Windows.Forms.ListBox MatBox3;
        public System.Windows.Forms.NumericUpDown MatSel;
        public System.Windows.Forms.ListBox MatBox4;
        private System.Windows.Forms.Button TB;
        private System.Windows.Forms.Label CL;
        private System.Windows.Forms.TextBox pfo;
        private System.Windows.Forms.Timer CheckOver;
    }
}

