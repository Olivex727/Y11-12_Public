﻿using System;
using System.IO;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using TradeGameMod.MainModule;
using TradeGameMod.Load;
using Newtonsoft.Json;

namespace TradeGame
{
    public partial class TradeGame : Form
    {
        public string intf = "title";
        public bool gameon = false;
        public bool gamesc = false;
        public bool save = false;

        public Module mod = new Module();

        public string file = "";

        public TradeGame()
        {
            InitializeComponent();
            LoadMod();
        }

        public void GetDir()
        {
            string path = @"C:\OWEngine\Saves\TradeGame";
            try
            {
                GameList.Items.Clear();
                foreach (string title in Directory.GetFiles(path, "*.json"))
                {
                    GameList.Items.Add(title);
                }
            }
            catch (Exception e)
            {
                Console.WriteLine(e.Message + ", GetPath");
            }
        }

        public void SaveGame(bool init)
        {
            if(init)
            {
                j = JsonConvert.SerializeObject(mod, Formatting.Indented);
            }
            using (StreamWriter sw = new StreamWriter(@file))
            {
                sw.Flush();
                sw.WriteLine(j);
                sw.Close();
            }
            save = true;
        }

        public void LoadGame()
        {
            using (StreamReader f = new StreamReader(@file))
            {
                JsonSerializer s = new JsonSerializer();
                j = f.ReadToEnd();
                mod = JsonConvert.DeserializeObject<Module>(j);
                f.Close();
            }
            save = true;
        }

        public string j = "";

        public void NewGame()
        {
            //string path = @"C:\OWEngine\Data\TradeGame\defaults\Mod.json";

            try { File.Create(@file).Close(); } catch(Exception e) { Console.WriteLine(e.Message + ", CreateNewFile"); }

            /*
            using (StreamReader f = new StreamReader(path))
            {
                JsonSerializer s = new JsonSerializer();
                j = f.ReadToEnd();
                mod = JsonConvert.DeserializeObject<Module>(j);
                f.Close();
            }
            */
            creategame g = new creategame();
            g.createMod();
            mod = g.mod;
            SaveGame(true);

        }

        public void ChangeIntf(string scene)
        {
            if (scene == "title")
            {
                intf = "title";
                LGlabel.Tag = intf;
                NGlabel.Tag = intf;
                title.Tag = intf;
                CredLabel.Tag = intf;
                QLabel.Tag = intf;
                title.Text = "Oliver Walters' Trading Game";
                NGlabel.Text = "New Game";
                LGlabel.Text = "Load Game";
                CredLabel.Text = "Credits";
                QLabel.Text = "Quit";
                bck.Tag = intf;
            }
            else if (scene == "credits")
            {
                intf = "credits";
                LGlabel.Tag = "credits";
                title.Tag = "credits";
                CredLabel.Tag = intf;
                QLabel.Tag = intf;
                title.Text = "< Back";
                NGlabel.Text = "This is a game made by";
                LGlabel.Text = "Oliver Walters";
                CredLabel.Text = "for Y11 SDD";
                QLabel.Text = "Visit my github page (Olivex727) for more.";
                bck.Tag = intf;
            }
            else if (scene == "load")
            {
                GetDir();
                intf = "load";
                title.Tag = intf;
                NGlabel.Tag = intf;
                title.Text = "< Back";
                NGlabel.Text = "Select a Game";
                LGlabel.Text = "Load Game";
                bck.Tag = intf;
                gamesc = false;
            }
            else if (scene == "game")
            {
                bool un = true;
                foreach(string s in GameList.Items) { if (s == @"C:\OWEngine\Saves\TradeGame\" + textBox1.Text + ".json") { un = false; } }
                if (intf == "load") { file = GameList.SelectedItem.ToString(); LoadGame(); }
                else if (intf == "new" && un) { file = @"C:\OWEngine\Saves\TradeGame\"+ textBox1.Text+".json"; NewGame(); }
                ChangeIntf("main");
            }
            else if (scene == "new")
            {
                intf = "new";
                title.Tag = intf;
                NGlabel.Tag = intf;
                title.Text = "< Back";
                NGlabel.Text = "Enter a Name";
                LGlabel.Text = "Create Game";
                bck.Tag = intf;
                gamesc = false;
            }
            else if (scene == "main")
            {
                intf = "main";
                gameon = true;
                gamesc = true;
                GameTitle.Text = "Portfolio";
            }
            else if (scene == "map")
            {

            }
            else if (scene == "market")
            {

            }
            else if (scene == "mat")
            {

            }
        }

        private void Main_Load(object sender, EventArgs e)
        {

        }

        private void Map_Click(object sender, EventArgs e)
        {
            
        }

        private void saveGameToolStripMenuItem_Click(object sender, EventArgs e)
        {
            SaveGame(true);
        }

        private void loadGameToolStripMenuItem_Click(object sender, EventArgs e)
        {
            if (!save)
            {
                DialogResult ds = MessageBox.Show("Are you sure you want to quit without saving?", "Ouitting...", MessageBoxButtons.YesNo, MessageBoxIcon.Question);
                //if(ds.ToString())
            }
            ChangeIntf("load");
        }

        private void quitToTitleToolStripMenuItem_Click(object sender, EventArgs e)
        {
            if (!save) { MessageBox.Show("Are you sure you want to quit without saving?", "Ouitting...", MessageBoxButtons.YesNo, MessageBoxIcon.Question); }
            
            ChangeIntf("title");
            gameon = false;
        }

        private void mainPortfolioToolStripMenuItem_Click(object sender, EventArgs e)
        {
            intf = "main";
        }

        private void materialsToolStripMenuItem_Click(object sender, EventArgs e)
        {
            intf = "mat";
        }

        private void marketToolStripMenuItem_Click(object sender, EventArgs e)
        {
            intf = "market";
        }

        private void travelToolStripMenuItem_Click(object sender, EventArgs e)
        {
            intf = "map";
        }

        private void GameCheck_Tick(object sender, EventArgs e)
        {
#pragma warning disable CS0252 // Possible unintended reference comparison; left hand side needs cast
            //foreach (Control c in Controls){ c.Visible = false; }
            foreach (Control c in Controls) { if ((c.Tag == intf && c.Name != "Menu")||(c.Tag == "game" && gameon && gamesc && intf != "map")) { c.Visible = true; } else if (c.Name != "Menu") { c.Visible = false; } }
#pragma warning restore CS0252 // Possible unintended reference comparison; left hand side needs cast
            if (!gameon)
            {
                Menu.Visible = false;
            }
            else { Menu.Visible = true; }
            this.Width = 1204;
            this.Height = 739;
            if (gameon) { IntfTimer.Enabled = true; }
            else { IntfTimer.Enabled = false; }
        }

        private void NGlabel_Click(object sender, EventArgs e)
        {
            if (intf == "title")
            {
                ChangeIntf("new");
            }
            else if (intf == "new")
            {
                ChangeIntf("game");
            }
        }

        private void LGlabel_Click(object sender, EventArgs e)
        {
            if (intf == "title")
            {
                ChangeIntf("load");
            }
            else if (intf == "load")
            {
                ChangeIntf("game");
            }
            else if (intf == "new")
            {
                ChangeIntf("game");
            }
        }

        private void CredLabel_Click(object sender, EventArgs e)
        {
            if (intf == "title")
            {
                ChangeIntf("credits");
            }
        }

        private void QLabel_Click(object sender, EventArgs e)
        {
            if (intf == "title")
            { this.Dispose(); }
        }

        private void title_Click(object sender, EventArgs e)
        {
            if(intf == "credits" || (intf == "load" && !gameon) || (intf == "new" && !gameon))
            {
                ChangeIntf("title");
            }
            if ((intf == "load" && gameon) || (intf == "new" && gameon))
            {
                ChangeIntf("main");
            }
        }

        private void GameList_SelectedIndexChanged(object sender, EventArgs e)
        {
            LGlabel.Tag = "load";
        }

        private void textBox1_TextChanged(object sender, EventArgs e)
        {
            if (textBox1.Text != "") { LGlabel.Tag = "new"; }
            else { LGlabel.Tag = "title"; }
        }

        private void TurnButton_Click(object sender, EventArgs e)
        {
            foreach (string s in mod.order.Values) { Console.WriteLine(s); }
            mod.playerturn = false;
            for (int i = 0; i < mod.order.Count(); i++)
            { mod.takeTurn(mod.turn, mod.getClass(mod.turn)[0], mod.getClass(mod.turn)[1]); mod.cutInflation(); }
            mod.time += 0.25;
            save = false;
            mod.print();
        }

        private void IntfTimer_Tick(object sender, EventArgs e)
        {
            TL.Text = "Time: " + mod.time;
        }

        public void LoadMod()
        {
            /*
            string path = @"C:\OWEngine\Data\TradeGame\defaults\Mod.json";
            
            string json = JsonConvert.SerializeObject(mod, Formatting.Indented);
            using (StreamWriter sw = new StreamWriter(path))
            {
                sw.Flush();
                sw.WriteLine(json);
                sw.Close();
            }
            */
        }
    }
}
