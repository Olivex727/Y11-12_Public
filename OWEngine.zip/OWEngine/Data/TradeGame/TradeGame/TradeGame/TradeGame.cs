﻿using System;
using System.IO;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using TradeGameMod.MainModule;
using TradeGameMod.Load;
using Newtonsoft.Json;

namespace TradeGame
{
    public partial class TradeGame : Form
    {
        public string intf = "title";
        public bool gameon = false;
        public bool gamesc = false;
        public bool save = false;

        public NPC player = new NPC();

        public Module mod = new Module();

        public string file = "";

        public TradeGame()
        {
            InitializeComponent();
            //LoadMod();
        }

        public void GetDir()
        {
            string path = @"C:\OWEngine\Saves\TradeGame";
            try
            {
                GameList.Items.Clear();
                foreach (string title in Directory.GetFiles(path, "*.json"))
                {
                    GameList.Items.Add(title);
                }
            }
            catch (Exception e)
            {
                Console.WriteLine(e.Message + ", GetPath");
            }
        }

        public void SaveGame(bool init)
        {
            if(init)
            {
                j = JsonConvert.SerializeObject(mod, Formatting.Indented);
            }
            using (StreamWriter sw = new StreamWriter(@file))
            {
                sw.Flush();
                sw.WriteLine(j);
                sw.Close();
            }
            save = true;
        }

        public void LoadGame()
        {
            using (StreamReader f = new StreamReader(@file))
            {
                JsonSerializer s = new JsonSerializer();
                j = f.ReadToEnd();
                mod = JsonConvert.DeserializeObject<Module>(j);
                f.Close();
            }
            save = true;
        }

        public string j = "";

        public void NewGame()
        {
            //string path = @"C:\OWEngine\Data\TradeGame\defaults\Mod.json";

            try { File.Create(@file).Close(); } catch(Exception e) { Console.WriteLine(e.Message + ", CreateNewFile"); }

            /*
            using (StreamReader f = new StreamReader(path))
            {
                JsonSerializer s = new JsonSerializer();
                j = f.ReadToEnd();
                mod = JsonConvert.DeserializeObject<Module>(j);
                f.Close();
            }
            */
            creategame g = new creategame();
            g.createMod();
            mod = g.mod;
            SaveGame(true);

        }

        public void ChangeIntf(string scene)
        {
            SI = "";
            index = -1;
            if (scene == "title")
            {
                intf = "title";
                LGlabel.Tag = intf;
                NGlabel.Tag = intf;
                title.Tag = intf;
                CredLabel.Tag = intf;
                QLabel.Tag = intf;
                title.Text = "Oliver Walters' Trading Game";
                NGlabel.Text = "New Game";
                LGlabel.Text = "Load Game";
                CredLabel.Text = "Credits";
                QLabel.Text = "Quit";
                bck.Tag = intf;
            }
            else if (scene == "credits")
            {
                intf = "credits";
                LGlabel.Tag = "credits";
                title.Tag = "credits";
                CredLabel.Tag = intf;
                QLabel.Tag = intf;
                title.Text = "< Back";
                NGlabel.Text = "This is a game made by";
                LGlabel.Text = "Oliver Walters";
                CredLabel.Text = "for Y11 SDD";
                QLabel.Text = "Visit my github page (Olivex727) for more.";
                bck.Tag = intf;
            }
            else if (scene == "load")
            {
                GetDir();
                intf = "load";
                title.Tag = intf;
                NGlabel.Tag = intf;
                title.Text = "< Back";
                NGlabel.Text = "Select a Game";
                LGlabel.Text = "Load Game";
                bck.Tag = intf;
                gamesc = false;
            }
            else if (scene == "game")
            {
                bool un = true;
                foreach(string s in GameList.Items) { if (s == @"C:\OWEngine\Saves\TradeGame\" + textBox1.Text + ".json") { un = false; } }
                if (intf == "load" && GameList.SelectedItem != null) { file = GameList.SelectedItem.ToString(); LoadGame(); }
                else if (intf == "new" && un) { file = @"C:\OWEngine\Saves\TradeGame\"+ textBox1.Text+".json"; NewGame(); }
                ChangeIntf("main");
            }
            else if (scene == "new")
            {
                intf = "new";
                title.Tag = intf;
                NGlabel.Tag = intf;
                title.Text = "< Back";
                NGlabel.Text = "Enter a Name";
                LGlabel.Text = "Create Game";
                bck.Tag = intf;
                gamesc = false;
            }
            else if (scene == "main")
            {
                intf = "main";
                gameon = true;
                gamesc = true;
                GameTitle.Text = "Portfolio";
                Help.Text = "This is your main Portfolio Area.";
                foreach (NPC n in mod.Players)
                {
                    if (n.type == "p") { player = n; }
                }
                
            }
            else if (scene == "map")
            {
                intf = "map";
                Help.Text = "Click on a city name to change location.";
            }
            else if (scene == "market")
            {
                intf = "market";
                Help.Text = "This provides information on properties and banks in your location.";
                GameTitle.Text = "Market";
                scene = "UpdateMarBox";
                MatBox1.Items.Clear(); MatBox1.Tag = intf;
                MatBox2.Items.Clear(); MatBox2.Tag = intf;
                MatBox3.Items.Clear(); MatBox3.Tag = intf;
                MatBox4.Items.Clear(); MatBox4.Tag = intf;
                ML.Tag = intf; ML.Text = "Deposit/Withdraw loans/Stores:";
                MatSel.Tag = intf; MatAdd.Tag = intf;
                MatLabel.Tag = intf; MatLabel.Text = "# Market Areas (Worth):    Cost/Intrest|Maintain Cost/Debt, Units/HQ | Capacity,          Developed|Debtor";
            }
            else if (scene == "mat")
            {
                intf = "mat";
                Help.Text = "This is where you can buy and sell materials.";
                GameTitle.Text = "Materials";
                scene = "UpdateMatBox";
                ML.Tag = intf; ML.Text = "Add/Remove Items from inventory:";
                MatSel.Tag = intf; MatAdd.Tag = intf;
                MatLabel.Tag = intf; MatLabel.Text = "#  Materials (Net Worth):          Cost | Amount                   Inflation | Anchor                Inventory";
                MatBox1.Items.Clear(); MatBox1.Tag = intf;
                MatBox2.Items.Clear(); MatBox2.Tag = intf;
                MatBox3.Items.Clear(); MatBox3.Tag = intf;
                MatBox4.Items.Clear(); MatBox4.Tag = intf;
            }
            else if (scene == "gg")
            {
                CheckOver.Enabled = false;
                SaveGame(true);
                ChangeIntf("title");
                gameon = false;
                MessageBox.Show("Game Over. Your Time: " + mod.time.ToString() + ", Your score: " + player.score.ToString(), "Quitting...", MessageBoxButtons.OK, MessageBoxIcon.Information);
                
            }
            if (scene == "UpdateMatBox")
            {
                MatBox1.Items.Clear(); MatBox1.Tag = intf;
                MatBox2.Items.Clear(); MatBox2.Tag = intf;
                MatBox3.Items.Clear(); MatBox3.Tag = intf;
                MatBox4.Items.Clear(); MatBox4.Tag = intf;
                int co = 0;
                foreach (Material m in mod.Materials)
                {
                    MatBox1.Items.Add(co.ToString() + " " + m.name + " (" + Math.Round(m.netWorth()) + ")");
                    MatBox2.Items.Add(Math.Round(m.cost, 2).ToString() + "             " + m.amount.ToString());
                    MatBox3.Items.Add(Math.Round(m.inflation, 2).ToString() + "             " + m.anchor);
                    MatBox4.Items.Add(player.invent[m.name].ToString());
                    co++;
                }
            }
            if (scene == "UpdateMarBox")
            {
                MatBox1.Items.Clear(); MatBox1.Tag = intf;
                MatBox2.Items.Clear(); MatBox2.Tag = intf;
                MatBox3.Items.Clear(); MatBox3.Tag = intf;
                MatBox4.Items.Clear(); MatBox4.Tag = intf;
                int co = 0;
                foreach (Facility m in mod.Locs)
                {
                    if ((m.location.name == player.location || toggle) && !chooseBank && m.location != null)
                    {
                        MatBox1.Items.Add(co.ToString() + "#F" + " " + m.name + " (" + Math.Round(m.netWorth("worth")) + ")");
                        MatBox2.Items.Add(m.cost.ToString() + "             " + Math.Round(m.mcost).ToString());
                        MatBox3.Items.Add(m.units.ToString() + "             " + m.cap);
                        MatBox4.Items.Add(m.developed.ToString() + "             " + m.debt);
                    }
                    co++;
                }
                co = 0;
                foreach (Institute m in mod.Banks)
                {
                    if ((m.head.name == player.location || toggle || chooseBank ) && !m.repo)
                    {
                        MatBox1.Items.Add(co.ToString() + "#B" + co.ToString() + " " + m.name + " (" + m.reserve + ")");
                        MatBox2.Items.Add(m.intrest.ToString() + "             " + m.debtlen.ToString());
                        MatBox3.Items.Add(m.head.name);
                        //MatBox4.Items.Add("");
                    }
                    co++;
                }
            }
        }

        //public Dictionary<string, int> MatBoxList = new Dictionary<string, int>();

        private void Main_Load(object sender, EventArgs e)
        {

        }

        private void Map_Click(object sender, EventArgs e)
        {
            int x = Cursor.Position.X;
            int y = Cursor.Position.Y;
        }

        private void saveGameToolStripMenuItem_Click(object sender, EventArgs e)
        {
            SaveGame(true);
        }

        private void loadGameToolStripMenuItem_Click(object sender, EventArgs e)
        {
            ChangeIntf("load");
        }

        private void quitToTitleToolStripMenuItem_Click(object sender, EventArgs e)
        {
            bool load = true;
            if (!save && gameon)
            {
                DialogResult ds = MessageBox.Show("Are you sure you want to quit without saving?", "Ouitting...", MessageBoxButtons.YesNo, MessageBoxIcon.Question);
                if (ds.ToString() == "Yes") { load = true; }
                else if (ds.ToString() == "No") { load = false; }
            }
            if (load)
            {
                ChangeIntf("title");
                gameon = false;
            }
        }

        private void mainPortfolioToolStripMenuItem_Click(object sender, EventArgs e)
        {
            ChangeIntf("main");
        }

        private void materialsToolStripMenuItem_Click(object sender, EventArgs e)
        {
            ChangeIntf("mat");
        }

        private void marketToolStripMenuItem_Click(object sender, EventArgs e)
        {
            ChangeIntf("market");
        }

        private void travelToolStripMenuItem_Click(object sender, EventArgs e)
        {
            ChangeIntf("map");
        }

        private void GameCheck_Tick(object sender, EventArgs e)
        {
#pragma warning disable CS0252 // Possible unintended reference comparison; left hand side needs cast
            //foreach (Control c in Controls){ c.Visible = false; }
            foreach (Control c in Controls) { if ((c.Tag == intf && c.Name != "Menu")||(c.Tag == "game" && gameon && gamesc && intf != "map") || (c.Tag == "fgame" && gameon && gamesc)) { c.Visible = true; } else if (c.Name != "Menu") { c.Visible = false; } }
#pragma warning restore CS0252 // Possible unintended reference comparison; left hand side needs cast
            if (!gameon)
            {
                Menu.Visible = false;
            }
            else { Menu.Visible = true; }
            this.Width = 1204;
            this.Height = 739;
            if (gameon) { IntfTimer.Enabled = true; CheckOver.Enabled = true; }
            else { IntfTimer.Enabled = false; CheckOver.Enabled = false; }

        }

        private void NGlabel_Click(object sender, EventArgs e)
        {
            if (intf == "title")
            {
                ChangeIntf("new");
            }
            else if (intf == "new")
            {
                ChangeIntf("game");
            }
        }

        private void LGlabel_Click(object sender, EventArgs e)
        {
            bool load = true;
            if (!save && gameon)
            {
                DialogResult ds = MessageBox.Show("Are you sure you want to quit without saving?", "Ouitting...", MessageBoxButtons.YesNo, MessageBoxIcon.Question);
                if (ds.ToString() == "Yes"){ load = true; }
                else if (ds.ToString() == "No") { load = false; }
            }
            if (intf == "title")
            {
                ChangeIntf("load");
            }
            else if (intf == "load")
            {
                if (load) { ChangeIntf("game"); }
            }
            else if (intf == "new")
            {
                if (load) { ChangeIntf("game"); }
            }
        }

        private void CredLabel_Click(object sender, EventArgs e)
        {
            if (intf == "title")
            {
                ChangeIntf("credits");
            }
        }

        private void QLabel_Click(object sender, EventArgs e)
        {
            if (intf == "title")
            { this.Dispose(); }
        }

        private void title_Click(object sender, EventArgs e)
        {
            if(intf == "credits" || (intf == "load" && !gameon) || (intf == "new" && !gameon))
            {
                ChangeIntf("title");
            }
            if ((intf == "load" && gameon) || (intf == "new" && gameon))
            {
                ChangeIntf("main");
            }
        }

        private void GameList_SelectedIndexChanged(object sender, EventArgs e)
        {
            if (GameList.SelectedItem != null) { LGlabel.Tag = "load"; }
        }

        private void textBox1_TextChanged(object sender, EventArgs e)
        {
            if (textBox1.Text != "") { LGlabel.Tag = "new"; }
            else { LGlabel.Tag = "title"; }
        }

        public void TurnButton_Click(object sender, EventArgs e)
        {
            foreach (string s in mod.order.Values) { Console.WriteLine(s); }
            mod.playerturn = false;
            for (int i = 0; i < mod.order.Count(); i++)
            { mod.takeTurn(mod.turn, mod.getClass(mod.turn)[0], mod.getClass(mod.turn)[1]); mod.cutInflation(); }
            mod.time += 0.25;
            save = false;
            mod.print();
            player.score += Convert.ToUInt64(player.netWorth(mod.Materials));
            foreach (NPC n in mod.Players)
            {
                if (n.type == "p") { mod.Players.Remove(n);break; }
            }
            mod.Players.Add(player);
            ChangeIntf(intf);
        }

        private void IntfTimer_Tick(object sender, EventArgs e)
        {
            TL.Text = "Time: " + mod.time;
            LocL.Text = "Location: " + player.location;
            foreach (Market m in mod.LocList) { if (m.name == player.location) { CL.Text = "Currency: " + m.currency.name; } }
            foreach(Market m in mod.LocList)
            {
                if(m.name == player.location)
                {
                    currency = m.currency;
                }
            }
            //CheckGameOver("debt");
            string invc = "";
            foreach (string s in player.invent.Keys)
            {
                invc += "; " + s + ", " + player.invent[s].ToString();
            }
            string proc = "";
            int pro = 0;
            foreach (Facility f in mod.Locs)
            {
                if (f.anchor == player.name) { pro ++; proc += "; " + f.name + " (" + f.netWorth("worth").ToString() + ")"; }
            }
            int debt = 0;
            foreach (Institute i in mod.Banks)
            {
                debt += i.reserve;
            }
            string ng = "";
            foreach (string s in player.NoGo)
            {
                ng += "; " + s;
            }
            pfo.Text = "Net Worth: "+ Convert.ToUInt64(player.netWorth(mod.Materials)).ToString() +
                "\r\n\r\nInventory" + invc +
                "\r\n\r\nProperty" + proc +
                "\r\n\r\nDebt: " + debt.ToString() +
                "\r\n\r\nBanned From" + ng +
                "\r\n\r\nScore: " + player.score;
            if(player.netWorth(mod.Materials) + pro + debt <= 0)
            {
                mod.gameover = true;
            }
        }

        public void CheckGameOver(string op)
        {
            Console.WriteLine("START NEXT");
            if (op == "debt")
            {
                bool go = false;
                string l = "";
                foreach (Institute i in mod.Banks)
                {

                    Console.WriteLine("{0}, {1}", i.name, !i.repo);
                    if ((i.debtlen > 8 || Math.Abs(i.reserve) > 10000000) && !i.repo)
                    {
                        go = true;
                        l = i.head.name;
                        i.repoBank();
                        int x = -1;
                        player.NoGo.Add(i.head.name);
                        foreach (Facility f in mod.Locs)
                        {
                            if (f.debt == i.name)
                            {
                                f.repoProperty();
                                x = mod.Locs.IndexOf(f);
                            }
                        }
                        if (x >= 0) { mod.Locs.RemoveAt(x); }
                        break;
                    }

                }
                Console.WriteLine("End Foreach");
                if (go) { MessageBox.Show("You're now banned at " + l + " due to your debt or the bank's debt. If you're there now, you won't come back again", "", MessageBoxButtons.OK, MessageBoxIcon.None); }
            }
            if (op == "full")
            {
                if (mod.gameover && gameon)
                {
                    ChangeIntf("gg");
                }
            }
        }

        private void Map_MouseClick(object sender, MouseEventArgs e)
        {
            //ML.Text = "X: " + e.X + ", Y:" + e.Y;
            Dictionary<string, int[]> pos = new Dictionary<string, int[]>();
            pos.Add("Shenton", new int[] { 340, 110, 420, 130 });
            pos.Add("Nesbia", new int[] { 555, 180, 620, 200 });
            pos.Add("Central", new int[] { 620, 135, 680, 155 });
            pos.Add("Dapton", new int[] { 740, 400, 810, 420 });
            pos.Add("Rockcrop Bay", new int[] { 280, 380, 400, 400 });
            pos.Add("Iron Island", new int[] { 160, 500, 265, 520 });
            foreach (string s in pos.Keys)
            {
                int[] i = pos[s];
                if (e.X >= i[0] && e.X <= i[2])
                {
                    if (e.Y >= i[1] && e.Y <= i[3])
                    {
                        if (!player.NoGo.Contains(s))
                        {
                            string[] msg = mod.rng(s, player);
                            if (msg[1] != "")
                            {
                                DialogResult ds = MessageBox.Show(msg[1], "", MessageBoxButtons.OK, MessageBoxIcon.Information);
                            }
                            player.location = msg[0];
                            if (msg[2] == "!")
                            {
                                throw new Exception("Too Bad, You Lost");
                            }

                            else if (msg[2] == "lol") { TurnButton_Click(null, EventArgs.Empty); }

                        }
                    }
                }
            }
        }

        public string SI = "";
        public int index = -1;
        public int matcost = 0;
        public Material currency;
        public int PTD = -1;

        private void MatAdd_Click(object sender, EventArgs e)
        {
            save = false;
            if (intf == "mat")
            {
                foreach (Material m in mod.Materials)
                {
                    if (m.name == currency.name)
                    {
                        if (SI != "" && index >= 0)
                        {
                            if (
                                MatSel.Value >= -1 * player.invent[SI] && MatSel.Value <= mod.Materials.ToArray()[index].amount
                                && m.amount - matcost >= 0 && player.invent[m.name] + matcost >= 0
                                )
                            {
                                if (SI != currency.name)
                                {
                                    player.invent[SI] += Convert.ToInt32(MatSel.Value);
                                    mod.Materials.ToArray()[index].amount -= Convert.ToInt32(MatSel.Value);

                                    m.amount -= matcost;
                                    player.invent[m.name] += matcost;
                                    ChangeIntf("UpdateMatBox");
                                }
                                else
                                {
                                    MessageBox.Show("Please select something other than your location's currency.", "", MessageBoxButtons.OK, MessageBoxIcon.None);
                                }
                            }
                            else
                            {
                                MessageBox.Show("Insufficient Funds.", "", MessageBoxButtons.OK, MessageBoxIcon.None);
                            }
                        }
                    }
                }
            }
            if (intf == "market" && MatAdd.Text == "Add/Remove")
            {
                if (SI != "" && index >= 0)
                {
                    if(mod.Locs.ToArray()[index].units + MatSel.Value <= mod.Locs.ToArray()[index].cap
                        && mod.Locs.ToArray()[index].units + MatSel.Value >= 0
                        && player.invent[mod.Locs.ToArray()[index].mat.name] - MatSel.Value >= 0
                        && mod.Locs.ToArray()[index].developed
                        )
                    {
                        player.invent[mod.Locs.ToArray()[index].mat.name] -= Convert.ToInt32(MatSel.Value);
                        mod.Locs.ToArray()[index].units += Convert.ToInt32(MatSel.Value);
                    }
                    else
                    {
                        MessageBox.Show("Unowned Property, Insufficient Funds or too large of a Deposit.", "", MessageBoxButtons.OK, MessageBoxIcon.None);
                    }

                }
            }
            if (intf == "market" && MatAdd.Text == "Withdraw/Deposit")
            {
                foreach (Material m in mod.Materials)
                {
                    if (m.name == mod.Banks.ToArray()[index].head.currency.name)
                    {
                        if (SI != "" && index >= 0)
                        {
                            if (
                                MatSel.Value >= -1 * player.invent[mod.Banks.ToArray()[index].head.currency.name]
                                && Math.Abs(MatSel.Value + mod.Banks.ToArray()[index].reserve) < 10000
                                )
                            {
                                mod.Banks.ToArray()[index].reserve -= Convert.ToInt32(MatSel.Value);
                                player.invent[mod.Banks.ToArray()[index].head.currency.name] += Convert.ToInt32(MatSel.Value);
                                ChangeIntf("UpdateMarBox");
                            }
                            else
                            {
                                MessageBox.Show("Insufficient Funds or too large of a Withdrawal. Get more of the currency that the banks deal in. Banks will refuse Loans of over 10000", "", MessageBoxButtons.OK, MessageBoxIcon.None);
                            }
                        }
                    }
                }
            }
            if (intf == "market" && MatAdd.Text == "Buy Property")
            {
                if (atLoc)
                {
                    MatBox1.Items.Clear(); MatBox2.Items.Clear(); MatBox3.Items.Clear(); MatBox4.Items.Clear();
                    PTD = index; TB.Text = "Cancel"; MatAdd.Text = "Choose Bank"; toggle = true; chooseBank = true; ChangeIntf("UpdateMarBox");
                }
                else { MessageBox.Show("You must be at the location to buy the property.", "", MessageBoxButtons.OK, MessageBoxIcon.None); }

            }
            else if(intf == "market" && MatAdd.Text == "Choose Bank")
            {
                mod.Locs.ToArray()[PTD].developProperty(mod.Players.ToArray()[0], mod.Banks.ToArray()[index]);
                toggle = false; chooseBank = false; TB.Text = "Toggle"; MatAdd.Text = "Add/Remove"; MatBox1.SelectedItem = null; ChangeIntf("UpdateMarBox");
            }
        }

        private void MatSel_ValueChanged(object sender, EventArgs e)
        {
            if (SI != "" && index >= 0)
            {
                if (intf == "mat")
                {
                    matcost = -1 * Convert.ToInt32(Convert.ToDouble(MatSel.Value) * mod.Materials.ToArray()[index].cost / currency.cost);
                    ML.Text = "Cost in Currency: " + matcost.ToString();
                }
                if (intf == "market")
                {

                }
            }
        }
        public bool atLoc = true;

        private void MatBox_SelectedIndexChanged(object sender, EventArgs e)
        {
            if (MatBox1.SelectedItem != null)
            {
                if (intf == "mat")
                {
                    SI = mod.Materials.ToArray()[MatBox1.SelectedIndex].name;
                    index = MatBox1.SelectedIndex;
                    MatSel.Maximum = mod.Materials.ToArray()[MatBox1.SelectedIndex].amount;
                    MatSel.Minimum = -1 * player.invent[mod.Materials.ToArray()[MatBox1.SelectedIndex].name];
                }
                if (intf == "market" && MatBox1.SelectedItem.ToString().ToCharArray()[2] == 'F' && !chooseBank)
                {
                    foreach (Facility m in mod.Locs)
                    {
                        if (m.name == mod.Locs.ToArray()[int.Parse(MatBox1.SelectedItem.ToString().ToCharArray()[0].ToString())].name)
                        {
                            if (m.developed) { MatAdd.Text = "Add/Remove"; MatSel.Tag = "market"; }
                            else { MatAdd.Text = "Buy Property"; MatSel.Tag = ""; }
                            SI = mod.Locs.ToArray()[int.Parse(MatBox1.SelectedItem.ToString().ToCharArray()[0].ToString())].name;
                            index = int.Parse(MatBox1.SelectedItem.ToString().ToCharArray()[0].ToString());
                            foreach (Material mats in mod.Materials) { if (mats.name == mod.Locs.ToArray()[index].mat.name) { MatSel.Maximum = player.invent[mats.name]; } };
                            MatSel.Minimum = - mod.Locs.ToArray()[index].units;
                            if (m.location.name != player.location)
                            {
                                atLoc = false;
                            }
                            else
                            {
                                atLoc = true;
                            }
                        }
                    }
                }
                if (intf == "market" && MatBox1.SelectedItem.ToString().ToCharArray()[2] == 'B')
                {
                    foreach (Institute m in mod.Banks)
                    {
                        if (m.name == mod.Banks.ToArray()[int.Parse(MatBox1.SelectedItem.ToString().ToCharArray()[0].ToString())].name)
                        {
                            if (!chooseBank) { MatAdd.Text = "Withdraw/Deposit"; MatSel.Tag = "market"; }
                            index = int.Parse(MatBox1.SelectedItem.ToString().ToCharArray()[0].ToString());
                            SI = mod.Banks.ToArray()[int.Parse(MatBox1.SelectedItem.ToString().ToCharArray()[0].ToString())].name;
                            MatSel.Maximum = 1000;
                            MatSel.Minimum = -1 * player.invent[mod.Banks.ToArray()[index].head.currency.name];
                        }
                    }
                }

            }
        }

        public bool toggle = false;

        public bool chooseBank = false;

        private void TB_Click(object sender, EventArgs e)
        {
            if (!chooseBank)
            {
                if (!toggle) { toggle = true; } else { toggle = false; }
                ChangeIntf("UpdateMarBox");
            }
            else
            {
                toggle = false; chooseBank = false; TB.Text = "Toggle"; MatAdd.Text = "Add/Remove"; MatBox1.SelectedItem = null; ChangeIntf("UpdateMarBox");
            }
        }

        private void CheckOver_Tick(object sender, EventArgs e)
        {
            CheckGameOver("full");
            CheckGameOver("debt");
        }
    }
}
