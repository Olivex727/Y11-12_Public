﻿using System.IO;
using Newtonsoft.Json;
using System;
using TradeGameMod.MainModule;
using System.Collections.Generic;

namespace TradeGameMod.Load
{
    class creategame
    {
        Random r = new Random();

        public Module mod = new Module();

        public void createMod()
        {
            mod.time = 0;
            mod.difficulty = 1;
            mod.initialize();
            Material iron = new Material
            {
                name = "Iron",
                type = "r",
                cost = r.Next(100,500),
                influx = 9,
                amount = 100
            };
            Material copper = new Material
            {
                name = "Copper",
                type = "r",
                cost = r.Next(50, 200),
                influx = 11,
                amount = 100
            };
            Material stone = new Material
            {
                name = "Stone",
                type = "r",
                cost = r.Next(25, 100),
                influx = 11,
                amount = 100
            };
            Material wood = new Material
            {
                name = "Wood",
                type = "r",
                cost = r.Next(5, 50),
                influx = 11,
                amount = 100
            };
            Material uranium = new Material
            {
                name = "Uranium",
                type = "r",
                cost = r.Next(200, 1000),
                influx = 11,
                amount = 100
            };
            Material Base = new Material
            {
                name = "Money",
                type = "c",
                cost = 1,
                influx = 0,
                amount = 10000,
                anchor = "Central"
            };
            Material Gold = new Material
            {
                name = "Gold",
                type = "c",
                cost = r.Next(1, 50),
                influx = 0,
                amount = 10000,
                anchor = "RockCrop"
            };
            Market Central = new Market()
            {
                name = "Central",
                type = "e",
                markup = Convert.ToDouble(r.Next(500, 2000)) / 1000,
                currency = Base,
                travel = new List<string>() { "Dapton", "Nesbia", "Shenton" }
            };
            Market Nesbia = new Market()
            {
                name = "Nesbia",
                type = "e",
                markup = Convert.ToDouble(r.Next(500, 2000)) / 1000,
                currency = Base,
                travel = new List<string>() { "Dapton", "Central", "Shenton" }
            };
            Market RCB = new Market()
            {
                name = "Rockcrop Bay",
                type = "e",
                markup = Convert.ToDouble(r.Next(500, 2000)) / 1000,
                currency = Base,
                travel = new List<string>() { "Iron Island", "Shenton", "Dapton" }
            };
            Market Dapton = new Market()
            {
                name = "Dapton",
                type = "e",
                markup = Convert.ToDouble(r.Next(500, 2000)) / 1000,
                currency = Gold,
                travel = new List<string>() { "Nesbia", "Dapton", "Rockcrop Bay" }
            };
            Market Shenton = new Market()
            {
                name = "Shenton",
                type = "e",
                markup = Convert.ToDouble(r.Next(500, 2000)) / 1000,
                currency = Gold,
                travel = new List<string>() { "Nesbia", "Central", "Rockcrop Bay" }
            };
            Market II = new Market()
            {
                name = "Iron Island",
                type = "e",
                markup = Convert.ToDouble(r.Next(500, 2000)) / 1000,
                currency = Gold,
                travel = new List<string>() { "Rockcrop Bay" }
            };
            mod.Materials.Add(copper); mod.Materials.Add(iron); mod.Materials.Add(Base);
            mod.Materials.Add(uranium); mod.Materials.Add(Gold); mod.Materials.Add(wood);
            mod.Materials.Add(stone);
            mod.LocList.Add(Central); mod.LocList.Add(Nesbia); mod.LocList.Add(RCB);
            mod.LocList.Add(Dapton); mod.LocList.Add(Shenton); mod.LocList.Add(II);
            Facility WoodShed = new Facility()
            {
                name = "Wood Shed",
                type = "s",
                location = Shenton,
                cc = r.Next(50, 200),
                cap = 1000,
                mat = wood,
                mcost = wood.cost
            };
            Facility Quarry = new Facility()
            {
                name = "Quarry",
                type = "s",
                location = RCB,
                cc = r.Next(100, 500),
                cap = 1000,
                mat = stone,
                mcost = stone.cost
            };
            Facility Mineshaft = new Facility()
            {
                name = "Mineshaft",
                type = "s",
                location = II,
                cc = r.Next(900, 1500),
                cap = 1000,
                mat = iron,
                mcost = iron.cost
            };
            Facility Reactor = new Facility()
            {
                name = "Reactor",
                type = "s",
                location = Dapton,
                cc = r.Next(2000, 5000),
                cap = 1000,
                mat = uranium,
                mcost = uranium.cost
            };
            mod.Locs.Add(Quarry); mod.Locs.Add(WoodShed);
            mod.Locs.Add(Mineshaft); mod.Locs.Add(Reactor);

            Institute CenBank = new Institute()
            {
                name = "CenBank",
                head = Central,
                intrest = Convert.ToDouble(r.Next(500, 2000)) / 1000,
                reserve = 0
            };
            Institute Eastpac = new Institute()
            {
                name = "Eastpac",
                head = Dapton,
                intrest = Convert.ToDouble(r.Next(500, 2000)) / 1000,
                reserve = 0
            };
            Institute StGeoff = new Institute()
            {
                name = "St. Geoff",
                head = RCB,
                intrest = Convert.ToDouble(r.Next(500, 2000)) / 1000,
                reserve = 0
            };
            Institute GS = new Institute()
            {
                name = "Golden Sacks",
                head = Nesbia,
                intrest = Convert.ToDouble(r.Next(500, 2000)) / 1000,
                reserve = 0
            };
            mod.Banks.Add(CenBank); mod.Banks.Add(Eastpac);
            mod.Banks.Add(StGeoff); mod.Banks.Add(GS);
            NPC Player = new NPC()
            {
                name = "player",
                type = "p",
                location = Central.name
            };
            Player.invent = new Dictionary<string, int>();
            foreach (Material m in mod.Materials) { Player.invent.Add(m.name, 0); }
            Player.manageInvent("add", Base, 10000);
            mod.Players.Add(Player);
            mod.createTurnOrder();
            mod.rnd = new Random();
        }
    }
}