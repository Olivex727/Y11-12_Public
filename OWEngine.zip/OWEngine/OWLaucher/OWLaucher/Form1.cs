﻿using System;
using System.IO;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using webmod;

namespace OWLaucher
{
    public partial class Form1 : Form
    {
        LauncherWebClient wlc = new LauncherWebClient();
        IPmsg ip = new IPmsg();
        string IP = "";

        public bool menu = true;
        public bool instflag = true;
        Dictionary<string, string> ds;
        //public string game = "";

        public Form1()
        {
            InitializeComponent();
        }

        public void Form1_Load(object sender, EventArgs e)
        {
            while (ip.returnIP() == "") { IP = @ip.returnIP()+@":80/download/"; }
            download("info.txt");
            //getGitHub();
            Glist.Items.Clear();
            ds = htmlToList();
            foreach (string s in ds.Keys)
            {
                Glist.Items.Add(s);
            }
            
        }

        public void launchGame()
        {
            //Open sln file of CS Project
        }

        public Dictionary<string, string> htmlToList()
        {
            //Get online html/json and put to list
            Dictionary<string, string> l = new Dictionary<string, string>();

            l.Add("loloo", "gnreogubenjo\r\nregkrerejnergerognreog");
            l.Add("CYOA11", "gnreogubenesog");

            return l;
        }

        public void download(string dir)
        {
            //Download folders
            wlc.run_download(IP + dir, @"C://OWEngine/Data/" + dir);
        }

        private void GB_Enter(object sender, EventArgs e)
        {

        }

        private void B1_Click(object sender, EventArgs e)
        {
            if (menu)
            {
                //Go to Github
            }
            else if (instflag)
            {
                //Install using download();
            }
            else
            {
                //Launch game using launchGame();
            }
        }

        private void B2_Click(object sender, EventArgs e)
        {
            if (menu)
            {
                this.Dispose();
            }
            else
            {
                menu = true;
                Desc.Text = getGitHub();
            }
        }

        private void check_Tick(object sender, EventArgs e)
        {
            string t = @"C:\\OWEngine/Data\";
            if (!menu) { t += Glist.SelectedItem.ToString(); }
            instflag = true;
            try
            {
                foreach (string title in Directory.GetDirectories(@"C:\\OWEngine/Data"))
                {
                    //Console.WriteLine(title + ", " + t);
                    if (title == t)
                    {
                        instflag = false;
                    }
                }
            }
            catch (Exception ex)
            {
                Console.WriteLine(ex.Message + ex.Data + ", checktick");
                
            }

            if (menu)
            {
                B1.Text = "Go to Github";
                B2.Text = "Quit";
            }
            else if(instflag)
            {
                B1.Text = "Install";
                B2.Text = "Menu";
            }
            else
            {
                B1.Text = "Launch";
                B2.Text = "Menu";
            }
            
        }

        private void Glist_SelectedIndexChanged(object sender, EventArgs e)
        {
            
            try{ Desc.Text = ds[Glist.SelectedItem.ToString()]; }
            finally { menu = false; }
        }

        public string getGitHub()
        {
            //Download folders
            //return wlc.getRepoLog(@"Olivex727/Y11-12_Public", @"C:\OWEngine\OWLaucher\OWLauchertest.js");
            return "fewfwefew";
        }
    }
    public class WebMod
    {

    }
}
