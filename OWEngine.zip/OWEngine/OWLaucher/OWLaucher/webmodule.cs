﻿using System;
using System.IO;
using System.Collections.Generic;
using System.Diagnostics;
using System.Net;
using System.Web;
using System.Net.Http;
using System.Windows.Forms;

namespace webmod
{
    public class LauncherWebClient
    {
        //static void Main(string[] args)
        //{
            //Console.WriteLine("");
            //run_cmd(@"../test.py", "s");
            //run_download(
            //, "info.txt");
            //getRepoLog("Olivex727/Y11-12_Public", "../test.js");


        //}

        public string getRepoLog(string site, string dir)
        {
            //dir = ;
            string log = "";
            var contents = "";
            site = "https://github.com/" + site;
            //try
            //{
                using (var client = new WebClient())
                {
                    contents = client.DownloadString(site);
                    //Console.WriteLine(contents);
                }
                //return contents.ToString();

                
                WebBrowser wb = new WebBrowser();

                wb.Url = new Uri(String.Format(dir, Directory.GetCurrentDirectory()));
                wb.ScriptErrorsSuppressed = true;

                object[] args = { contents.ToString() };
                object l = wb.Document.InvokeScript("clickElement", args);
                if(l != null)
                {
                    log = l.ToString();
                }

            //}
            //catch (Exception e)
            //{
                //Console.WriteLine(e.Message+", getRepoLog");
            //}

            return log;
        }
        public void run_download(string website, string file)
        {
            try
            {
                using (WebClient wc = new WebClient())
                {
                    wc.DownloadFile(website, file);
                }
            }
            catch (Exception e)
            {
                Console.WriteLine(e.Message);
            }
        }
    }
}