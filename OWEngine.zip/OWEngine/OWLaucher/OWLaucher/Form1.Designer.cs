﻿namespace OWLaucher
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            this.Glist = new System.Windows.Forms.ListBox();
            this.GB = new System.Windows.Forms.GroupBox();
            this.Desc = new System.Windows.Forms.RichTextBox();
            this.B2 = new System.Windows.Forms.Button();
            this.B1 = new System.Windows.Forms.Button();
            this.check = new System.Windows.Forms.Timer(this.components);
            this.GB.SuspendLayout();
            this.SuspendLayout();
            // 
            // Glist
            // 
            this.Glist.BackColor = System.Drawing.Color.DarkBlue;
            this.Glist.Font = new System.Drawing.Font("Franklin Gothic Medium", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Glist.ForeColor = System.Drawing.SystemColors.InactiveBorder;
            this.Glist.FormattingEnabled = true;
            this.Glist.ItemHeight = 21;
            this.Glist.Location = new System.Drawing.Point(12, 12);
            this.Glist.Name = "Glist";
            this.Glist.Size = new System.Drawing.Size(135, 424);
            this.Glist.TabIndex = 0;
            this.Glist.SelectedIndexChanged += new System.EventHandler(this.Glist_SelectedIndexChanged);
            // 
            // GB
            // 
            this.GB.BackColor = System.Drawing.Color.DarkSlateBlue;
            this.GB.Controls.Add(this.Desc);
            this.GB.Controls.Add(this.B2);
            this.GB.Controls.Add(this.B1);
            this.GB.Font = new System.Drawing.Font("Franklin Gothic Medium", 7.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.GB.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.GB.Location = new System.Drawing.Point(153, 12);
            this.GB.Name = "GB";
            this.GB.Size = new System.Drawing.Size(635, 426);
            this.GB.TabIndex = 1;
            this.GB.TabStop = false;
            this.GB.Text = "Welcome to launcher";
            this.GB.Enter += new System.EventHandler(this.GB_Enter);
            // 
            // Desc
            // 
            this.Desc.BackColor = System.Drawing.Color.DarkSlateGray;
            this.Desc.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.Desc.Font = new System.Drawing.Font("Franklin Gothic Medium", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Desc.ForeColor = System.Drawing.SystemColors.Window;
            this.Desc.Location = new System.Drawing.Point(27, 33);
            this.Desc.Name = "Desc";
            this.Desc.Size = new System.Drawing.Size(590, 340);
            this.Desc.TabIndex = 2;
            this.Desc.Text = "Welcome to the OW Launcher. All games are available here!";
            // 
            // B2
            // 
            this.B2.BackColor = System.Drawing.Color.MidnightBlue;
            this.B2.Location = new System.Drawing.Point(513, 379);
            this.B2.Name = "B2";
            this.B2.Size = new System.Drawing.Size(116, 41);
            this.B2.TabIndex = 1;
            this.B2.Text = "Quit";
            this.B2.UseVisualStyleBackColor = false;
            this.B2.Click += new System.EventHandler(this.B2_Click);
            // 
            // B1
            // 
            this.B1.BackColor = System.Drawing.Color.MidnightBlue;
            this.B1.Location = new System.Drawing.Point(6, 379);
            this.B1.Name = "B1";
            this.B1.Size = new System.Drawing.Size(116, 41);
            this.B1.TabIndex = 0;
            this.B1.Text = "Go to GitHub";
            this.B1.UseVisualStyleBackColor = false;
            this.B1.Click += new System.EventHandler(this.B1_Click);
            // 
            // check
            // 
            this.check.Enabled = true;
            this.check.Tick += new System.EventHandler(this.check_Tick);
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.Indigo;
            this.ClientSize = new System.Drawing.Size(800, 450);
            this.Controls.Add(this.GB);
            this.Controls.Add(this.Glist);
            this.Name = "Form1";
            this.Text = "OW Game Launcher";
            this.Load += new System.EventHandler(this.Form1_Load);
            this.GB.ResumeLayout(false);
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.ListBox Glist;
        private System.Windows.Forms.GroupBox GB;
        private System.Windows.Forms.Button B1;
        private System.Windows.Forms.Button B2;
        private System.Windows.Forms.Timer check;
        private System.Windows.Forms.RichTextBox Desc;
    }
}

