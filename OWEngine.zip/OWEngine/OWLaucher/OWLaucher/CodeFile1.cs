﻿/*
 * Display Webpage List of possible File Selections
 * Go to Download Webpage if not downloaded
 * 
 * Games.txt - Full of downloaded games
 */