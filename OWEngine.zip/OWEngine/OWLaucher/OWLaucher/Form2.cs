﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace OWLaucher
{
    public partial class IPmsg : Form
    {
        public bool enterIP = false;
        public string IP = "";
        public IPmsg()
        {
            InitializeComponent();
        }

        private void IPmsg_Load(object sender, EventArgs e)
        {

        }

        public string returnIP ()
        {
            if (enterIP) { return IP; }
            return "";
        }

        private void button1_Click(object sender, EventArgs e)
        {
            enterIP = true;
            IP = IPtxt.Text;
        }
    }
}
