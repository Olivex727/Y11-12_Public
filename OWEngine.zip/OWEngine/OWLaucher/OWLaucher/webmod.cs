﻿using System;
using System.IO;
using System.Collections.Generic;
using System.Diagnostics;
using System.Net;
using System.Web;
using System.Net.Http;
using System.Windows.Forms;

namespace testFile
{
    class Program
    {
        static void Main(string[] args)
        {
            //Console.WriteLine("");
            //run_cmd(@"../test.py", "s");
            //run_download(@"http://10.0.105.224:8080/download/"+args[0], "info.txt");
            getRepoLog("Olivex727/Y11-12_Public", "../test.js");


        }

        private static string getRepoLog(string site, string dir)
        {
            //dir = ;
            string log = "";
            var contents = "";
            site = "https://github.com/" + site;
            try
            {
                using (var client = new WebClient())
                {
                    contents = client.DownloadString(site);
                    Console.WriteLine(contents);
                }

                WebBrowser wb = new WebBrowser();

                dir = "../test.js";
                wb.Url = new Uri(String.Format(dir, Directory.GetCurrentDirectory()));
                wb.ScriptErrorsSuppressed = true;

                object[] args = { contents.ToString() };
                log = wb.Document.InvokeScript("clickElement", args).ToString();

            }
            catch (Exception e)
            {
                Console.WriteLine(e.Message);
            }

            return log;
        }

        private static void run_cmd(string cmd, string args)
        {
            try
            {
                ProcessStartInfo start = new ProcessStartInfo();
                start.FileName = cmd;
                Console.WriteLine("urbicue");
                //start.Arguments = string.Format("{0} {1}", cmd, args);
                start.UseShellExecute = false;
                start.RedirectStandardOutput = true;
                using (Process process = Process.Start(start))
                {
                    using (StreamReader reader = process.StandardOutput)
                    {
                        string result = reader.ReadToEnd();
                        Console.WriteLine(result);
                    }
                }
            }
            catch (Exception e)
            {
                Console.WriteLine(e.Message);
            }
        }
        private static void run_download(string website, string file)
        {
            try
            {

                //Uri ws = new Uri(website);
                //WebRequest wr = WebRequest.Create(ws);
                using (WebClient wc = new WebClient())
                {
                    wc.DownloadFile(website, file);
                }
            }
            catch (Exception e)
            {
                Console.WriteLine(e.Message);
            }
        }
    }
}
