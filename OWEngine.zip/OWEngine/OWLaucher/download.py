#Download info.txt and pipe to Desktop
import urllib.request
import os

#Get external inputs
url = input("Enter Url: ")
if url == "": url = "http://192.168.43.43:8000/download/info.txt"
loc = input("Enter Location: ")
if loc == "": loc = "C://OWEngine\Data"

#Download File
file = urllib.request.urlretrieve(url, loc+"Downloads.txt")
